#!/usr/bin/env python3
"""The Oregon Trail (Apple II) - native runtime launcher.  Put your own two disk images in ./disks (any names ending in .dsk).
Usage: python3 oregon.py [--disks DIR] [--saves DIR] [--backend auto|sdl2|pygame] [--windowed] [--selftest]"""
import sys, os, argparse, traceback
HERE=os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0,HERE)
def find_disks(folder):
    from disk import Disk
    found={}
    if not os.path.isdir(folder): return found
    for fn in sorted(os.listdir(folder)):
        p=os.path.join(folder,fn)
        if not os.path.isfile(p) or os.path.getsize(p)!=143360: continue            # 140 KB Apple II image, any extension
        try: d=Disk(p)
        except Exception: continue
        if d.has('HELLO') and d.has('OREGON TRAIL'): found.setdefault(1,p)
        elif d.has('FLOAT') or d.has('WIN'): found.setdefault(2,p)
    return found
def pick_backend(name,windowed,log):
    order=['sdl2','pygame'] if name=='auto' else [name]; last=None
    for n in order:
        try:
            if n=='sdl2':
                from frontend_sdl2 import SDL2Backend; return SDL2Backend(fullscreen=not windowed,log=log)
            from frontend_pygame import PygameBackend; return PygameBackend(fullscreen=not windowed,log=log)
        except Exception as e: last=e; log('backend',n,'unavailable:',e)
    raise RuntimeError('no usable display backend (need PySDL2 or pygame): %s'%last)
def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--disks',default=os.path.join(HERE,'disks')); ap.add_argument('--saves',default=os.path.join(HERE,'saves'))
    ap.add_argument('--backend',default='auto'); ap.add_argument('--windowed',action='store_true'); ap.add_argument('--selftest',action='store_true')
    a=ap.parse_args(); log=lambda *x:print(*x,flush=True)
    disks=find_disks(a.disks)
    if 1 not in disks or 2 not in disks:
        log('Missing disk images in',a.disks,'- recognised:',disks,'| files there:',os.listdir(a.disks) if os.path.isdir(a.disks) else 'folder missing',
            '\nPlace BOTH Oregon Trail Apple II disk images (140 KB DOS 3.3-order .dsk, disk 1 and disk 2) there.'); return 2
    from game import Game
    Game.save_dir=a.saves; g=Game(disks[1],disks[2])
    be=pick_backend(a.backend,a.windowed or a.selftest,log); log('backend:',be.name)
    from app import App
    app=App(g,be,log=log)
    if a.selftest:                                          # a short scripted run to check video/audio/input plumbing
        import time; t0=time.time(); be_poll=be.poll
        def poll():
            ev=be_poll()
            if time.time()-t0>5: ev.append(('quit',))
            return ev
        be.poll=poll
    err=app.run(); return 1 if err else 0
if __name__=='__main__':
    try: sys.exit(main())
    except SystemExit: raise
    except Exception: traceback.print_exc(); sys.exit(1)
