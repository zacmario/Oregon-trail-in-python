"""Apple II hunting sprites, read from the language-card image of disk 1 (tracks 6-8, loaded at $D100).
Format: header (width in bytes, height) followed by width*height raw bytes, row-major, 7 pixels/byte, bit0 = leftmost pixel."""
B=0xD100
ANIMAL={'bear':(0xD11E,[(0xD11E,4,14),(0xD158,4,14),(0xD192,4,14)]),
        'buffalo':(0xD1CC,[(0xD1CC,4,17),(0xD212,4,17),(0xD258,4,17)]),
        'deer':(0xD29E,[(0xD29E,4,18),(0xD2E8,4,18),(0xD332,4,18)]),
        'rabbit':(0xD37C,[(0xD37C,3,10),(0xD39C,3,10),(0xD3BC,3,10)]),
        'squirrel':(0xD3DC,[(0xD3DC,3,8),(0xD3F6,3,8),(0xD410,3,8)])}
DEAD={'deer':(0xD45E,4,20),'bear':(0xD4B0,4,14),'buffalo':(0xD4EA,4,17),'rabbit':(0xD57A,3,10),'squirrel':(0xD59A,3,8)}
TREES=[(0xD5B4,6,39),(0xD6A0,6,37),(0xD780,6,39),(0xD86C,6,40),(0xD95E,6,36),(0xDA38,6,40)]       # leafy x3, pine x3
BRUSH=[(0xDB2A,6,12),(0xDB74,6,14),(0xDBCA,6,14)]
OTHER=[(0xDC20,6,27),(0xDCC4,6,31),(0xDD80,6,26),(0xDE1E,6,23),(0xDEAA,6,20),(0xDF24,6,33)]
# hunter: 5 poses x 3 walk frames, 3x28 each, chained from $F7A2:  N(rifle up), NW, W, SW, S ; E-side poses are mirrors
HUNTER_BASE=0xF7A2
def _get(lc,a,w,h): p=a-B; return (w,h,bytes(lc[p+2:p+2+w*h]))
def flip(spr):
    w,h,data=spr; out=bytearray()
    for r in range(h):
        bits=[(data[r*w+k//7]>>(k%7))&1 for k in range(w*7)][::-1]
        for c in range(w): out.append(sum(bits[c*7+k]<<k for k in range(7)))
    return (w,h,bytes(out))
class Sprites:
    def __init__(self,disk1_bytes):
        lc=disk1_bytes[6*4096:9*4096]
        self.animal={n:[_get(lc,*f) for f in frames] for n,(_,frames) in ANIMAL.items()}
        self.animal_left={n:[flip(s) for s in fr] for n,fr in self.animal.items()}        # sprites face right natively
        self.dead={n:_get(lc,*d) for n,d in DEAD.items()}; self.dead_left={n:flip(s) for n,s in self.dead.items()}
        self.trees=[_get(lc,*t) for t in TREES]; self.brush=[_get(lc,*t) for t in BRUSH]; self.other=[_get(lc,*t) for t in OTHER]
        hs=[]; p=HUNTER_BASE-B
        for _ in range(15):
            w,h=lc[p],lc[p+1]; hs.append((w,h,bytes(lc[p+2:p+2+w*h]))); p+=2+w*h
        self.hunter=hs                                                                    # 0-2 N, 3-5 NW, 6-8 W, 9-11 SW, 12-14 S
        self.hunter_flip=[flip(s) for s in hs]
    def hunter_sprite(self,dirn,frame):
        """dirn index in hunt.DIRS order: 0=S,1=SE,2=E,3=NE,4=N,5=NW,6=W,7=SW"""
        pose={0:(4,False),1:(3,True),2:(2,True),3:(1,True),4:(0,False),5:(1,False),6:(2,False),7:(3,False)}[dirn]
        idx=[0,3,6,9,12][pose[0]]+frame%3          # pose order: 0=N,1=NW,2=W,3=SW,4=S
        return (self.hunter_flip if pose[1] else self.hunter)[idx]
