"""Small NMOS 6502 interpreter with Apple II style memory: flat 64K, language-card bank1/bank2 at $D000-$DFFF,
soft-switch hooks at $C000-$C0FF. No ROM image (the game keeps its own code in LC RAM)."""
class Halt(Exception): pass
class CPU:
    def __init__(self,mem=None):
        self.mem=mem if mem is not None else bytearray(65536)
        self.bank=[None,bytearray(4096),bytearray(4096)]   # [1]=bank1, [2]=bank2
        self.cur=2
        self.a=self.x=self.y=0; self.sp=0xFF; self.pc=0; self.p=0x24
        self.traps={}; self.keys=None; self.on_poll=None; self.spk=[]; self.cycles=0; self.on_idle=None
        self.build()
    # ---- memory ----
    def rd(self,a):
        if a<0xC000: return self.mem[a]
        if a<0xC100: return self.io(a,None)
        if 0xD000<=a<0xE000: return self.bank[self.cur][a-0xD000]
        return self.mem[a]
    def wr(self,a,v):
        if a<0xC000: self.mem[a]=v; return
        if a<0xC100: self.io(a,v); return
        if 0xD000<=a<0xE000: self.bank[self.cur][a-0xD000]=v; return
        self.mem[a]=v
    def io(self,a,v):
        if a==0xC000:
            if self.on_poll: self.on_poll()
            return (self.keys[0]|0x80) if (self.keys and v is None) else 0
        if a==0xC010:
            if self.keys: self.keys.pop(0)
            return 0
        if a==0xC030: self.spk.append(self.cycles); return 0
        if 0xC080<=a<=0xC08F: self.cur=1 if a&8 else 2; return 0
        return 0
    def poke_bank(self,bank,off,data):
        self.bank[bank][off:off+len(data)]=data
    # ---- stack/flags ----
    def push(self,v): self.mem[0x100+self.sp]=v&0xFF; self.sp=(self.sp-1)&0xFF
    def pull(self): self.sp=(self.sp+1)&0xFF; return self.mem[0x100+self.sp]
    def setnz(self,v):
        self.p=(self.p&0x7D)|(v&0x80)|(2 if (v&0xFF)==0 else 0)
    def call(self,addr,a=0,x=0,y=0,maxi=5_000_000,sentinel=0x0F0F):
        self.a,self.x,self.y=a,x,y; self.push((sentinel-1)>>8); self.push((sentinel-1)&0xFF); self.pc=addr
        n=0
        while self.pc!=sentinel:
            if self.pc in self.traps: self.traps[self.pc](self); continue
            self.step(); n+=1
            if n>maxi: raise Halt('instruction limit at %04X'%self.pc)
        return n
    # ---- decoding ----
    def build(self):
        T=[None]*256
        def add(op,f): T[op]=f
        rd,wr=self.rd,self.wr
        # addressing helpers return effective address
        def zp(c): v=rd(c.pc+1); c.pc+=2; return v
        def zpx(c): v=(rd(c.pc+1)+c.x)&0xFF; c.pc+=2; return v
        def zpy(c): v=(rd(c.pc+1)+c.y)&0xFF; c.pc+=2; return v
        def ab(c): v=rd(c.pc+1)|rd(c.pc+2)<<8; c.pc+=3; return v
        def abx(c): v=(rd(c.pc+1)|rd(c.pc+2)<<8)+c.x; c.pc+=3; return v&0xFFFF
        def aby(c): v=(rd(c.pc+1)|rd(c.pc+2)<<8)+c.y; c.pc+=3; return v&0xFFFF
        def inx(c):
            z=(rd(c.pc+1)+c.x)&0xFF; c.pc+=2; return rd(z)|rd((z+1)&0xFF)<<8
        def iny(c):
            z=rd(c.pc+1); c.pc+=2; return ((rd(z)|rd((z+1)&0xFF)<<8)+c.y)&0xFFFF
        def imm(c): v=c.pc+1; c.pc+=2; return v
        modes={'imm':imm,'zp':zp,'zpx':zpx,'zpy':zpy,'ab':ab,'abx':abx,'aby':aby,'inx':inx,'iny':iny}
        def alu(base,fn,order):
            for off,m in order.items(): add(base+off,(lambda m,fn: (lambda c: fn(c,rd(modes[m](c)))))(m,fn))
        grp1={0x09:'imm',0x05:'zp',0x15:'zpx',0x0D:'ab',0x1D:'abx',0x19:'aby',0x01:'inx',0x11:'iny'}
        def lda(c,v): c.a=v; c.setnz(v)
        def ora(c,v): c.a|=v; c.setnz(c.a)
        def and_(c,v): c.a&=v; c.setnz(c.a)
        def eor(c,v): c.a^=v; c.setnz(c.a)
        def adc(c,v):
            s=c.a+v+(c.p&1); c.p=(c.p&0x3C)|(1 if s>0xFF else 0)|(0x40 if (~(c.a^v)&(c.a^s)&0x80) else 0)
            c.a=s&0xFF; c.setnz(c.a)
        def sbc(c,v): adc(c,v^0xFF)
        def cmp_(c,v,r=None):
            r=c.a if r is None else r; t=r-v; c.p=(c.p&0x7C)|(1 if r>=v else 0); c.setnz(t&0xFF)
        for base,fn in ((0,ora),(0x20,and_),(0x40,eor),(0x60,adc),(0xA0,lda),(0xE0,sbc)):
            for off,m in grp1.items():
                op=(off&0x1F)|base if False else None
        ops={ 'ORA':(ora,{0x09:'imm',0x05:'zp',0x15:'zpx',0x0D:'ab',0x1D:'abx',0x19:'aby',0x01:'inx',0x11:'iny'}),
              'AND':(and_,{0x29:'imm',0x25:'zp',0x35:'zpx',0x2D:'ab',0x3D:'abx',0x39:'aby',0x21:'inx',0x31:'iny'}),
              'EOR':(eor,{0x49:'imm',0x45:'zp',0x55:'zpx',0x4D:'ab',0x5D:'abx',0x59:'aby',0x41:'inx',0x51:'iny'}),
              'ADC':(adc,{0x69:'imm',0x65:'zp',0x75:'zpx',0x6D:'ab',0x7D:'abx',0x79:'aby',0x61:'inx',0x71:'iny'}),
              'SBC':(sbc,{0xE9:'imm',0xE5:'zp',0xF5:'zpx',0xED:'ab',0xFD:'abx',0xF9:'aby',0xE1:'inx',0xF1:'iny'}),
              'LDA':(lda,{0xA9:'imm',0xA5:'zp',0xB5:'zpx',0xAD:'ab',0xBD:'abx',0xB9:'aby',0xA1:'inx',0xB1:'iny'}),
              'CMP':(cmp_,{0xC9:'imm',0xC5:'zp',0xD5:'zpx',0xCD:'ab',0xDD:'abx',0xD9:'aby',0xC1:'inx',0xD1:'iny'})}
        for nm,(fn,mm) in ops.items():
            for op,m in mm.items(): add(op,(lambda m,fn: (lambda c: fn(c,rd(modes[m](c)))))(m,fn))
        def ldx(c,v): c.x=v; c.setnz(v)
        def ldy(c,v): c.y=v; c.setnz(v)
        for op,m in {0xA2:'imm',0xA6:'zp',0xB6:'zpy',0xAE:'ab',0xBE:'aby'}.items(): add(op,(lambda m: lambda c: ldx(c,rd(modes[m](c))))(m))
        for op,m in {0xA0:'imm',0xA4:'zp',0xB4:'zpx',0xAC:'ab',0xBC:'abx'}.items(): add(op,(lambda m: lambda c: ldy(c,rd(modes[m](c))))(m))
        for op,m in {0xE0:'imm',0xE4:'zp',0xEC:'ab'}.items(): add(op,(lambda m: lambda c: cmp_(c,rd(modes[m](c)),c.x))(m))
        for op,m in {0xC0:'imm',0xC4:'zp',0xCC:'ab'}.items(): add(op,(lambda m: lambda c: cmp_(c,rd(modes[m](c)),c.y))(m))
        def bit(c,v): c.p=(c.p&0x3D)|(v&0xC0)|(2 if (c.a&v)==0 else 0)
        for op,m in {0x24:'zp',0x2C:'ab'}.items(): add(op,(lambda m: lambda c: bit(c,rd(modes[m](c))))(m))
        for op,m in {0x85:'zp',0x95:'zpx',0x8D:'ab',0x9D:'abx',0x99:'aby',0x81:'inx',0x91:'iny'}.items(): add(op,(lambda m: lambda c: wr(modes[m](c),c.a))(m))
        for op,m in {0x86:'zp',0x96:'zpy',0x8E:'ab'}.items(): add(op,(lambda m: lambda c: wr(modes[m](c),c.x))(m))
        for op,m in {0x84:'zp',0x94:'zpx',0x8C:'ab'}.items(): add(op,(lambda m: lambda c: wr(modes[m](c),c.y))(m))
        def rmw(fn):
            def mk(m):
                def f(c):
                    a=modes[m](c); v=fn(c,rd(a)); wr(a,v&0xFF)
                return f
            return mk
        def asl(c,v): c.p=(c.p&0xFE)|(v>>7); r=(v<<1)&0xFF; c.setnz(r); return r
        def lsr(c,v): c.p=(c.p&0xFE)|(v&1); r=v>>1; c.setnz(r); return r
        def rol(c,v): r=((v<<1)|(c.p&1))&0xFF; c.p=(c.p&0xFE)|(v>>7); c.setnz(r); return r
        def ror(c,v): r=(v>>1)|((c.p&1)<<7); c.p=(c.p&0xFE)|(v&1); c.setnz(r); return r
        def inc(c,v): r=(v+1)&0xFF; c.setnz(r); return r
        def dec(c,v): r=(v-1)&0xFF; c.setnz(r); return r
        for base,fn in ((0x00,asl),(0x20,rol),(0x40,lsr),(0x60,ror),(0xC0,dec),(0xE0,inc)):
            mk=rmw(fn)
            for off,m in ((6,'zp'),(0x16,'zpx'),(0xE,'ab'),(0x1E,'abx')): add(base+off,mk(m))
        for base,fn in ((0x0A,asl),(0x2A,rol),(0x4A,lsr),(0x6A,ror)): add(base,(lambda fn: lambda c: (c.__setattr__('a',fn(c,c.a)),c.__setattr__('pc',c.pc+1)))(fn))
        def br(cond):
            def f(c):
                o=rd(c.pc+1); c.pc+=2
                if cond(c): c.pc=(c.pc+(o-256 if o>127 else o))&0xFFFF
            return f
        add(0x10,br(lambda c: not c.p&0x80)); add(0x30,br(lambda c: c.p&0x80)); add(0x50,br(lambda c: not c.p&0x40)); add(0x70,br(lambda c: c.p&0x40))
        add(0x90,br(lambda c: not c.p&1)); add(0xB0,br(lambda c: c.p&1)); add(0xD0,br(lambda c: not c.p&2)); add(0xF0,br(lambda c: c.p&2))
        def imp(f):
            def g(c): f(c); c.pc+=1
            return g
        add(0xE8,imp(lambda c:(setattr(c,'x',(c.x+1)&0xFF),c.setnz(c.x)))); add(0xC8,imp(lambda c:(setattr(c,'y',(c.y+1)&0xFF),c.setnz(c.y))))
        add(0xCA,imp(lambda c:(setattr(c,'x',(c.x-1)&0xFF),c.setnz(c.x)))); add(0x88,imp(lambda c:(setattr(c,'y',(c.y-1)&0xFF),c.setnz(c.y))))
        add(0xAA,imp(lambda c:(setattr(c,'x',c.a),c.setnz(c.a)))); add(0xA8,imp(lambda c:(setattr(c,'y',c.a),c.setnz(c.a))))
        add(0x8A,imp(lambda c:(setattr(c,'a',c.x),c.setnz(c.a)))); add(0x98,imp(lambda c:(setattr(c,'a',c.y),c.setnz(c.a))))
        add(0xBA,imp(lambda c:(setattr(c,'x',c.sp),c.setnz(c.x)))); add(0x9A,imp(lambda c:setattr(c,'sp',c.x)))
        add(0x18,imp(lambda c:setattr(c,'p',c.p&0xFE))); add(0x38,imp(lambda c:setattr(c,'p',c.p|1)))
        add(0xD8,imp(lambda c:setattr(c,'p',c.p&0xF7))); add(0xF8,imp(lambda c:setattr(c,'p',c.p|8)))
        add(0x58,imp(lambda c:setattr(c,'p',c.p&0xFB))); add(0x78,imp(lambda c:setattr(c,'p',c.p|4)))
        add(0xB8,imp(lambda c:setattr(c,'p',c.p&0xBF))); add(0xEA,imp(lambda c:None))
        add(0x48,imp(lambda c:c.push(c.a))); add(0x08,imp(lambda c:c.push(c.p|0x30)))
        add(0x68,imp(lambda c:(setattr(c,'a',c.pull()),c.setnz(c.a)))); add(0x28,imp(lambda c:setattr(c,'p',(c.pull()&0xCF)|0x20)))
        def jmp(c): c.pc=rd(c.pc+1)|rd(c.pc+2)<<8
        def jmpi(c):
            a=rd(c.pc+1)|rd(c.pc+2)<<8; c.pc=rd(a)|rd((a&0xFF00)|((a+1)&0xFF))<<8
        def jsr(c):
            t=rd(c.pc+1)|rd(c.pc+2)<<8; r=c.pc+2; c.push(r>>8); c.push(r&0xFF); c.pc=t
        def rts(c): lo=c.pull(); hi=c.pull(); c.pc=((hi<<8|lo)+1)&0xFFFF
        def rti(c): c.p=(c.pull()&0xCF)|0x20; lo=c.pull(); hi=c.pull(); c.pc=hi<<8|lo
        def brk(c): raise Halt('BRK at %04X'%c.pc)
        add(0x4C,jmp); add(0x6C,jmpi); add(0x20,jsr); add(0x60,rts); add(0x40,rti); add(0x00,brk)
        self.T=T
    def step(self):
        op=self.mem[self.pc] if self.pc<0xC000 else self.rd(self.pc)
        f=self.T[op]
        if f is None: raise Halt('bad opcode %02X at %04X'%(op,self.pc))
        f(self); self.cycles+=3
