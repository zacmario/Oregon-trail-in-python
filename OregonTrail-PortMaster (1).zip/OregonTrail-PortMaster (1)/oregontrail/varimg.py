"""Parse an Applesoft variable-memory snapshot (VAR.BIN + PT.BIN) into Python values."""
import struct
def fp(b):  # 5-byte Applesoft float
    e=b[0]
    if e==0: return 0.0
    sign=-1 if b[1]&0x80 else 1
    m=((b[1]|0x80)<<24)|(b[2]<<16)|(b[3]<<8)|b[4]
    return sign*m/2**31*2**(e-129)
def name_of(b0,b1):
    n=chr(b0&0x7f)+(chr(b1&0x7f) if b1&0x7f else '')
    kind='str' if (b1&0x80 and not b0&0x80) else 'int' if (b1&0x80 and b0&0x80) else 'fn' if b0&0x80 else 'real'
    return n,kind
def key(n,kind): return n+{'str':'$','int':'%','real':'','fn':'()'}[kind]
def load(var,base,ptrs):
    vartab,arytab,strend,fretop,frespc,memsize=ptrs
    mem=lambda a: var[a-base]
    def getstr(l,p): return var[p-base:p-base+l].decode('latin1').translate(str.maketrans({chr(i):chr(i&0x7f) for i in range(128,256)})) if l else ''
    V={}; A={}
    a=vartab
    while a<arytab:
        n,kind=name_of(var[a-base],var[a-base+1]); v=var[a-base+2:a-base+7]
        if kind=='real': V[key(n,kind)]=fp(v)
        elif kind=='int': V[key(n,kind)]=float(struct.unpack('>h',bytes(v[0:2]))[0])
        elif kind=='str': V[key(n,kind)]=getstr(v[0],v[1]|v[2]<<8)
        a+=7
    a=arytab
    while a<strend:
        n,kind=name_of(var[a-base],var[a-base+1])
        size=var[a-base+2]|var[a-base+3]<<8; nd=var[a-base+4]
        dims=[var[a-base+5+2*i]<<8|var[a-base+6+2*i] for i in range(nd)]   # stored +1, last dim first? (see check)
        data=a+5+2*nd; cnt=1
        for d_ in dims: cnt*=d_
        vals=[]; p=data
        for i in range(cnt):
            if kind=='real': vals.append(fp(var[p-base:p-base+5])); p+=5
            elif kind=='int': vals.append(float(struct.unpack('>h',bytes(var[p-base:p-base+2]))[0])); p+=2
            else:
                l=var[p-base]; ptr=var[p-base+1]|var[p-base+2]<<8; vals.append(getstr(l,ptr) if l else ''); p+=3
        A[key(n,kind)]=(dims,vals)
        a+=size
    return V,A
if __name__=='__main__':
    import sys; sys.path.insert(0,'.')
    from disk import Disk
    d=Disk('/mnt/user-data/uploads/Oregon_Trail_Disk_1_of_2.dsk')
    pt=d.read('PT.BIN'); ptrs=[pt[i]|pt[i+1]<<8 for i in range(0,12,2)]
    V,A=load(d.read('VAR.BIN'),0x9902,ptrs)
    print(len(V),'simple vars'); print({k:(round(v,4) if isinstance(v,float) else v) for k,v in V.items()})
    print(len(A),'arrays')
    for k,(dims,vals) in A.items(): print(k,dims,vals[:8])
