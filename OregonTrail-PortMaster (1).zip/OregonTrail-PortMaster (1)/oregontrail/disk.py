"""DOS 3.3 .dsk reader (DOS-order images)."""
import os
TYPES={0:'T',1:'I',2:'A',4:'B',8:'S',16:'R'}
class Disk:
    def __init__(self,path):
        self.path=path; self.d=open(path,'rb').read()
        if len(self.d)!=143360: raise ValueError('not a 140K .dsk')
        self.cat={}
        t,s=17,15; seen=set()
        while t and (t,s) not in seen:
            seen.add((t,s)); b=self.sec(t,s)
            for i in range(7):
                e=b[11+i*35:11+(i+1)*35]
                if e[0] in (0,0xff): continue
                name=''.join(chr(c&0x7f) for c in e[3:33]).rstrip()
                self.cat[name]=(e[2]&0x7f,e[0],e[1])
            t,s=b[1],b[2]
    def sec(self,t,s): o=(t*16+s)*256; return self.d[o:o+256]
    def has(self,name): return name in self.cat
    def read(self,name):
        ft,t,s=self.cat[name]; data=bytearray(); seen=set()
        while t and (t,s) not in seen:
            seen.add((t,s)); l=self.sec(t,s)
            for i in range(122):
                dt,ds=l[12+i*2],l[13+i*2]
                data+= bytes(256) if (dt==0 and ds==0) else self.sec(dt,ds)
            t,s=l[1],l[2]
        data=bytes(data)
        if ft==2: n=data[0]|data[1]<<8; return data[2:2+n]          # Applesoft: raw program
        if ft==4: n=data[2]|data[3]<<8; return data[4:4+n]          # Binary: payload
        return data                                                 # text/other: raw sectors
    def readraw(self,name):
        ft,t,s=self.cat[name]; data=bytearray(); seen=set()
        while t and (t,s) not in seen:
            seen.add((t,s)); l=self.sec(t,s)
            for i in range(122):
                dt,ds=l[12+i*2],l[13+i*2]
                data+= bytes(256) if (dt==0 and ds==0) else self.sec(dt,ds)
            t,s=l[1],l[2]
        return bytearray(data)
    def load_addr(self,name):
        ft,t,s=self.cat[name]; assert ft==4
        l=self.sec(t,s); return self.sec(l[12],l[13])[0]|self.sec(l[12],l[13])[1]<<8
    def image_dos(self):  # tracks 0-5 runtime image
        return self.d[:6*4096]
