"""Handheld text/choice entry: Up/Down cycle through the allowed characters instead of typing on a keyboard.
Special key codes travel through Game.keys alongside normal ASCII codes."""
UP,DOWN,ACCEPT,BACK,FAST_UP,FAST_DOWN,CLASS=256,257,258,259,260,261,262
YESNO=set('YESNOyesno')
def candidates(allowed):
    """Ordered list of characters the player can cycle through for a given allowed-character set."""
    s=set(allowed)
    if s and s<=YESNO: return ['Y','N']
    up=[c for c in map(chr,range(65,91)) if c in s]; lo=[c for c in map(chr,range(97,123)) if c in s]
    dg=[c for c in map(chr,range(48,58)) if c in s]
    pu=[c for c in " .,'-" if c in s]
    out=up+lo+dg+pu if (up or lo) else dg+pu
    extra=[c for c in sorted(s) if 32<=ord(c)<127 and c not in out]
    out+=extra
    if any(ord(c)<32 for c in s): out.append('\x01')          # Ctrl-A: the main menu's "management options"
    return out or [' ']
def classes(cands):
    """Start indices of each character class (upper, lower, digits, punctuation) for the class-jump button."""
    starts=[]; prev=None
    for i,c in enumerate(cands):
        k='U' if c.isupper() else 'l' if c.islower() else 'd' if c.isdigit() else 'p'
        if k!=prev: starts.append(i); prev=k
    return starts
def handle(code,cands,idx):
    """Apply a cycle code; returns (new_index, action) where action is None, 'accept' or 'back'."""
    n=len(cands)
    if code==UP: return (idx-1)%n,None
    if code==DOWN: return (idx+1)%n,None
    if code==FAST_UP: return (idx-5)%n,None
    if code==FAST_DOWN: return (idx+5)%n,None
    if code==CLASS:
        st=classes(cands); nxt=[s for s in st if s>idx]; return (nxt[0] if nxt else st[0]),None
    if code==ACCEPT: return idx,'accept'
    if code==BACK: return idx,'back'
    return idx,None
def label(c): return {' ':'SPACE','\x01':'MENU'}.get(c,c)
