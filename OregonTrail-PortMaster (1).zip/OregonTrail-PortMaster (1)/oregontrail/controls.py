"""Maps handheld buttons to game keys depending on what the game is waiting for (Game.mode)."""
import ime
ARROW={'UP':11,'DOWN':10,'LEFT':8,'RIGHT':21}              # Apple II arrow key codes
CYCLE={'UP':ime.UP,'DOWN':ime.DOWN,'LEFT':ime.FAST_UP,'RIGHT':ime.FAST_DOWN,'A':ime.ACCEPT,'B':ime.BACK,'X':ime.CLASS,'START':13}
HUNT={'UP':11,'DOWN':10,'LEFT':8,'RIGHT':21,'A':32,'B':13,'X':ord(','),'Y':ord('.'),'START':27}
ANY=('A','B','X','Y','START','UP','DOWN','LEFT','RIGHT')
def route(game,button):
    """Translate a logical button press into entries on game.keys."""
    m=game.mode
    if m=='hunt': k=HUNT.get(button)
    elif m=='raft': k=ARROW.get(button)
    elif m in ('text','choice','digits'): k=CYCLE.get(button)
    else: k=32 if button in ANY else None                       # 'space' mode: any button continues
    if k is not None: game.keys.append(k)
def hint(game):
    """Two short lines for the on-screen help bar."""
    m=game.mode; p=getattr(game,'pending',None)
    cur=('[ %s ]  '%ime.label(p)) if p else ''
    if m in ('text','choice') and getattr(game,'ime_cands',None)==['Y','N']: return [cur+'UP/DOWN: Yes / No   A: select','']
    if m=='text': return [cur+'UP/DOWN: letter   A: add   B: delete','X: next group  L/R: skip 5   START: done']
    if m=='choice': return [cur+'UP/DOWN: choose   A: select','']
    if m=='digits': return [cur+'UP/DOWN: choose   A: select','B: undo   START: confirm']
    if m=='hunt': return ['D-pad: aim   A: fire   B: walk/stop','X/Y: turn rifle   START: end hunt']
    if m=='raft': return ['D-pad: steer the raft','']
    return ['Press any button to continue','']
