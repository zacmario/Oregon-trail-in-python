"""MECC proportional hi-res font from the runtime image (disk 1 tracks 0-5, base $3400, table at $6BEB).
Header: [?, first, last, 06, 08, 01, 01, 00]; records at table+8, 5 bytes: [advance, yshift, rows, off_lo, off_hi]
Glyph data: `rows` bytes at table+off, one byte per row, bit0 = leftmost pixel."""
class Font:
    def __init__(self,img,B=0x3400,tbl=0x6BEB):
        g=lambda a: img[a-B]
        self.first=g(tbl+1); self.last=g(tbl+2); self.hdr=[g(tbl+i) for i in range(8)]
        self.glyph={}
        for c in range(self.first,self.last+1):
            rec=tbl+8+5*(c-self.first)
            adv,shift,rows,lo,hi=[g(rec+i) for i in range(5)]
            off=lo|hi<<8
            self.glyph[c]=(adv,shift&0x1f if shift!=0x20 else 0,bytes(g(tbl+off+i) for i in range(rows)))
        # '$' and '*' use an undecoded overlay encoding (flag 0x20): build equivalents
        a,_,srows=self.glyph[ord('S')]
        self.glyph[ord('$')]=(7,-1,bytes([0x0C]+[r|0x0C for r in srows]+[0x0C]))
        self.glyph[ord('*')]=(6,1,bytes([0x15,0x0E,0x1F,0x0E,0x15]))
    def width(self,s): return sum(self.glyph.get(ord(c),(0,0,b''))[0] for c in s)
    def draw(self,put,x,y,ch):
        """put(px,py) sets a pixel; returns advance"""
        adv,shift,data=self.glyph.get(ord(ch)&0x7f,(6,0,b''))
        for r,b in enumerate(data):
            for k in range(8):
                if (b>>k)&1: put(x+k,y+shift+r)
        return adv
if __name__=='__main__':
    import sys; sys.path.insert(0,'.')
    from disk import Disk; from PIL import Image
    d=Disk('/mnt/user-data/uploads/Oregon_Trail_Disk_1_of_2.dsk'); f=Font(d.image_dos())
    from collections import Counter
    print('advance',Counter(v[0] for v in f.glyph.values()),'shift',Counter(v[1] for v in f.glyph.values()))
    im=Image.new('RGB',(280,40)); px=im.load()
    def put(x,y):
        if 0<=x<280 and 0<=y<40: px[x,y]=(255,255,255)
    for ln,txt in enumerate(["What is your choice? Wagon, oxen: 0123456789","The Oregon Trail; yg pq j, (Fort Kearney) 'Hi'!?","ABCDEFGHIJKLMNOPQRSTUVWXYZ abcdefghijklmnopqrstuvwxyz"][:3]):
        x=0
        for ch in txt: x+=f.draw(put,x,ln*13,ch)
    im.resize((1120,160),Image.NEAREST).save('/home/claude/ot/fonttest.png')
