"""Walk-around hunting minigame using the Apple II hunting sprites and the DOS release's rules (OREGON.EXE; see hunting_code/DOS_NOTES.md).
Timing (iterations; the DOS loop is paced to 7 iterations per 18.2 Hz tick = ~127/s):
  hunter walk step every 9 iterations by the direction vector; rifle turn every 5; bullet step every 4 iterations at 2x the vector
  animal step every <period> iterations (type table), +-4 px horizontal, vertical drift Random(5)-2; hunt ends after 564.2 ticks (31 s)
Hitboxes: full sprite rectangles (inclusive edges), bullet 2x2.   Vectors/muzzle offsets are DOS values (320x200) scaled to 280x192.
Controls: RETURN walk/stop; keypad digits 7 8 9 / 4 6 / 1 2 3 or arrow keys point the rifle (two arrows together = diagonal);
          < , / > . turn the rifle; SPACE fires (one bullet in flight at a time); ESC ends the hunt.
Interface: play(game, bullets, flags, skill) -> (pounds, bullets_left, kills)."""
import time, math, random
from hunt_sprites import Sprites
ITER_HZ=127.0; HUNT_TICKS=564.2
SX=280/320.0; SY=192/200.0
# DOS type table: (period_base, period_rand, pounds_base, pounds_rand, apple sprite, name)
TYPES=[(8,4,100,40,'deer','deer'),(8,10,200,200,'bear','bear'),(10,4,1700,300,'buffalo','buffalo'),
       (6,4,120,30,'deer','deer'),(4,4,2,8,'rabbit','rabbit'),(4,4,3,4,'squirrel','squirrel')]
# direction index: 0=S 1=SE 2=E 3=NE 4=N 5=NW 6=W 7=SW  (DOS dirs -4..3 reordered)
DIRS=[(0,1),(1,1),(1,0),(1,-1),(0,-1),(-1,-1),(-1,0),(-1,1)]
VEC=[(0,4),(4,2),(4,0),(4,-2),(0,-4),(-4,-2),(-4,0),(-4,2)]                       # DOS direction vectors (vx,vy)
MUZZLE=[(5,26),(22,12),(22,7),(23,0),(16,-1),(0,-1),(0,6),(0,11)]               # DOS muzzle offsets from hunter top-left
KEYPAD={ord('2'):0,ord('3'):1,ord('6'):2,ord('9'):3,ord('8'):4,ord('7'):5,ord('4'):6,ord('1'):7}
ARROW={10:(0,1),21:(1,0),11:(0,-1),8:(-1,0)}
TOP=11
def overlap(a,b):                                       # inclusive-edge AABB test as in the DOS code: (x,y,w,h)
    return not (b[0]+b[2]<a[0] or a[0]+a[2]<b[0] or b[1]+b[3]<a[1] or a[1]+a[3]<b[1])
def text(game,s,x,y):
    for ch in s: game.draw_char(x,y,ch,False); x+=game.advance(ch)
class Hunt:
    def __init__(self,game,bullets,flags,skill=1,seed=None):
        self.g=game; self.r=game.it.rnd if seed is None else random.Random(seed)
        if not hasattr(game,'sprites'): game.sprites=Sprites(game.disks[0].d)
        self.sp=game.sprites; self.bullets=bullets; self.pounds=0; self.kills=[]; self.msg=''; self.msg_t=0
        self.elig=[bool(flags[0]),bool(flags[1]),bool(flags[2]),True,True,True]
        hw,hh=self.sp.hunter[0][0]*7,self.sp.hunter[0][1]
        self.hw,self.hh=hw,hh; self.hx,self.hy=130.0,78.0; self.dir=2; self.walking=False; self.frame=0; self.arrows=[]
        self.bullet=None; self.iter=0; self.slots=[None,None]; self.timers=[1,1]; self.dead=[]
        self.obst=[]; woods=bool(flags[0]); pool=(self.sp.trees*2+self.sp.brush) if woods else (self.sp.brush+self.sp.other)
        n=self.r.randint(5,8); tries=0
        while len(self.obst)<n and tries<200:
            tries+=1; s=self.r.choice(pool); w,h=s[0]*7,s[1]
            x,y=14*self.r.randint(0,(279-w)//14),self.r.randint(TOP+1,191-h)       # even byte columns: the art's true colors
            rect=(x,y,w,h)
            if overlap(rect,(self.hx-6,self.hy-6,hw+12,hh+12)): continue
            if any(overlap(rect,(o[0],o[1],o[2],o[3])) for o in self.obst): continue
            self.obst.append((x,y,w,h,s))
        self.base=None
    def blocked(self,rect):
        x,y,w,h=rect
        if x<0 or x+w>279 or y<TOP+1 or y+h>191: return True
        return any(overlap(rect,(o[0],o[1],o[2],o[3])) for o in self.obst)
    def key(self,k):
        k&=0x7f
        if k in KEYPAD: self.dir=KEYPAD[k]
        elif k in ARROW:
            self.arrows=[(a,f) for a,f in self.arrows if self.iter-f<40]+[(ARROW[k],self.iter)]; d=ARROW[k]
            if len(self.arrows)>=2 and self.arrows[-2][0]!=d:
                c=(self.arrows[-2][0][0]+d[0],self.arrows[-2][0][1]+d[1])
                if c in DIRS: d=c
            self.dir=DIRS.index(d)
        elif k in (ord(','),ord('<')): self.dir=(self.dir-1)%8
        elif k in (ord('.'),ord('>')): self.dir=(self.dir+1)%8
        elif k==13: self.walking=not self.walking
        elif k==32 and self.bullet is None and self.bullets>0:
            self.bullets-=1; mx,my=MUZZLE[self.dir]; vx,vy=VEC[self.dir]
            self.bullet=[self.hx+mx*SX,self.hy+my*SY,2*vx*SX,2*vy*SY]
        elif k==27: return True
    def animal_rect(self,a): return (a['x'],a['y'],a['w'],a['h'])
    def spawn(self,i):
        if self.r.randint(0,99)>6: return
        for _ in range(20):
            t=self.r.randrange(6)
            if self.elig[t]: break
        else: return
        pb,pr,wb,wr,sname,name=TYPES[t]; fr=self.sp.animal[sname][0]; w,h=fr[0]*7,fr[1]
        left=self.r.random()<0.5; y=self.r.randint(TOP+2,190-h)
        a=dict(t=t,sname=sname,name=name,x=-w+1.0 if left else 278.0,y=float(y),dx=4*SX*(1 if left else -1),dy=(self.r.randint(0,4)-2)*SY,
               period=pb+self.r.randint(0,pr-1),lbs=wb+self.r.randint(0,wr-1),w=w,h=h,frame=0)
        if any(overlap(self.animal_rect(a),(o[0],o[1],o[2],o[3])) for o in self.obst): return
        self.slots[i]=a; self.timers[i]=a['period']
    def step(self):
        self.iter+=1
        if self.iter%9==0 and self.walking:                          # hunter walk step
            vx,vy=VEC[self.dir]; nx,ny=self.hx+vx*SX,self.hy+vy*SY
            if self.blocked((nx,ny,self.hw,self.hh)): self.walking=False
            else: self.hx,self.hy=nx,ny; self.frame=(self.frame+1)%3
        if self.iter%4==0 and self.bullet:                           # bullet step
            b=self.bullet; b[0]+=b[2]; b[1]+=b[3]; br=(b[0],b[1],2,2)
            hit=next((a for a in self.slots if a and overlap(br,self.animal_rect(a))),None)
            if hit:
                i=self.slots.index(hit); self.slots[i]=None; self.pounds+=hit['lbs']; self.kills.append(hit['name'])
                self.dead.append((hit['x'],hit['y'],hit['sname'],hit['dx']<0)); self.msg='You shot a %s! (%d lb)'%(hit['name'],hit['lbs']); self.msg_t=70; self.bullet=None
            elif b[0]<0 or b[0]>278 or b[1]<TOP or b[1]>191 or any(overlap(br,(o[0],o[1],o[2],o[3])) for o in self.obst): self.bullet=None
        for i in range(2):                                           # animal slots
            self.timers[i]-=1
            if self.timers[i]>0: continue
            a=self.slots[i]
            if a:
                nx,ny=a['x']+a['dx'],min(max(a['y']+a['dy'],TOP+1),191-a['h']); a['frame']=(a['frame']+1)%3
                if any(overlap((nx,ny,a['w'],a['h']),(o[0],o[1],o[2],o[3])) for o in self.obst): a['dy']=-a['dy']; ny=a['y']; nx=a['x']
                a['x'],a['y']=nx,ny
                if a['x']<-a['w']-4 or a['x']>284: self.slots[i]=None
                self.timers[i]=a['period'] if self.slots[i] else 1
            else:
                self.spawn(i); self.timers[i]=self.slots[i]['period'] if self.slots[i] else 4
        if self.msg_t: self.msg_t-=1
    def draw(self):
        g=self.g; s=g.scr
        if self.base is None:
            s.clear()
            for x,y,w,h,spr in sorted(self.obst,key=lambda o:o[1]+o[3]): g.draw_sprite(x,y,spr[0],spr[1],spr[2],'or')
            self.base=bytearray(s.scr)
        s.scr[:]=self.base
        for x,y,name,faces_left in self.dead:
            spr=(self.sp.dead_left if faces_left else self.sp.dead)[name]; g.draw_sprite(int(x),int(y),spr[0],spr[1],spr[2],'or')
        items=[]
        for a in self.slots:
            if a:
                fr=(self.sp.animal_left if a['dx']<0 else self.sp.animal)[a['sname']][a['frame']]; items.append((a['y']+a['h'],int(a['x']),int(a['y']),fr))
        items.append((self.hy+self.hh,int(self.hx),int(self.hy),self.sp.hunter_sprite(self.dir,self.frame if self.walking else 0)))
        for _,x,y,spr in sorted(items,key=lambda t:t[0]): g.draw_sprite(x,y,spr[0],spr[1],spr[2],'or')
        if self.bullet: s.fill(int(self.bullet[0]),int(self.bullet[1]),int(self.bullet[0])+1,int(self.bullet[1])+1,3)
        s.fill(0,0,279,TOP-1,0)
        left=max(0,int((HUNT_TICKS-self.iter/7.0)/18.2))
        text(g,'Bullets: %d'%self.bullets,3,1); text(g,'Meat: %d lb'%self.pounds,104,1); text(g,'Time: %d'%left,215,1)
        if self.msg_t: s.fill(40,176,239,191,0); text(g,self.msg,60,182)
def play(game,bullets,flags=(1,1,1),skill=1,seed=None):
    if not hasattr(flags,'__len__'): flags=(flags,1,1)
    h=Hunt(game,bullets,flags,skill,seed); end_wait=0
    while h.iter/7.0<HUNT_TICKS:
        t0=time.time()
        if getattr(game,'quit',False): break
        while game.keys:
            if h.key(game.keys.pop(0)): return h.pounds,h.bullets,h.kills
        for _ in range(4): h.step()
        h.draw(); game.snap('HUNT')
        if h.bullets<=0 and h.bullet is None:
            end_wait+=1
            if end_wait>40: break
        if not getattr(game,'headless',True): time.sleep(max(0,4/ITER_HZ-(time.time()-t0)))
    return h.pounds,h.bullets,h.kills
