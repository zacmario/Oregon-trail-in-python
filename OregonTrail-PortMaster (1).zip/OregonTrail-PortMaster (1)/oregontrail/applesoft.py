"""Minimal Applesoft BASIC interpreter that runs original tokenized programs.
Not an emulator: no 6502. Hardware/ROM/& calls are routed to Python hooks."""
import math, random, re

TOK=("END FOR NEXT DATA INPUT DEL DIM READ GR TEXT PR# IN# CALL PLOT HLIN VLIN HGR2 HGR HCOLOR= HPLOT DRAW XDRAW HTAB HOME ROT= SCALE= SHLOAD TRACE NOTRACE NORMAL INVERSE FLASH COLOR= POP VTAB HIMEM: LOMEM: ONERR RESUME RECALL STORE SPEED= LET GOTO RUN IF RESTORE & GOSUB RETURN REM STOP ON WAIT LOAD SAVE DEF POKE PRINT CONT LIST CLEAR GET NEW TAB( TO FN SPC( THEN AT NOT STEP + - * / ^ AND OR > = < SGN INT ABS USR FRE SCRN( PDL POS SQR RND LOG EXP COS SIN TAN ATN PEEK LEN STR$ VAL ASC CHR$ LEFT$ RIGHT$ MID$").split()

class AppleError(Exception):
    def __init__(s,code,msg=''): super().__init__(msg or str(code)); s.code=code
class Stop(Exception): pass

def lex_line(b):
    toks=[]; i=0; n=len(b)
    while i<n:
        c=b[i]
        if c>=0x80:
            kw=TOK[c-0x80] if c-0x80<len(TOK) else '?'
            i+=1
            if kw=='REM': toks.append(('R',bytes(b[i:]).decode('latin1'))); break
            toks.append(('K',kw))
            if kw=='DATA':
                j=i; q=False
                while j<n and (q or b[j]!=0x3A):
                    if b[j]==0x22: q=not q
                    j+=1
                toks.append(('D',bytes(b[i:j]).decode('latin1'))); i=j
        elif c==0x22:
            j=i+1
            while j<n and b[j]!=0x22: j+=1
            toks.append(('S',bytes(b[i+1:j]).decode('latin1'))); i=j+1
        elif 0x30<=c<=0x39 or c==0x2E:
            m=re.match(rb'\d*\.?\d*(?:E[+-]?\d+)?',bytes(b[i:i+40]))
            s=m.group(0); i+=len(s); toks.append(('N',float(s.decode()))) 
        elif (0x41<=c<=0x5A or 0x61<=c<=0x7A) and toks and toks[-1]==('K','&'):
            j=i
            while j<n and (0x41<=b[j]<=0x5A or 0x61<=b[j]<=0x7A): j+=1
            toks.append(('C',bytes(b[i:j]).decode().upper())); i=j
        elif 0x41<=c<=0x5A or 0x61<=c<=0x7A:
            j=i
            while j<n and (0x41<=b[j]<=0x5A or 0x30<=b[j]<=0x39 or 0x61<=b[j]<=0x7A): j+=1
            name=bytes(b[i:j]).decode().upper()[:2] if False else bytes(b[i:j]).decode().upper()
            suf=''
            if j<n and b[j] in (0x24,0x25): suf=chr(b[j]); j+=1
            toks.append(('I',name[:2]+suf)); i=j
        elif c==0x20: i+=1
        else: toks.append(('O',chr(c&0x7f))); i+=1
    return toks

def parse_program(raw):
    lines={}; p=0
    while p+4<=len(raw):
        nxt=raw[p]|raw[p+1]<<8
        if nxt==0: break
        ln=raw[p+2]|raw[p+3]<<8; q=p+4
        while q<len(raw) and raw[q]!=0: q+=1
        lines[ln]=lex_line(raw[p+4:q]); p=q+1
    return lines

def fmt_num(v):
    if v==int(v) and abs(v)<1e9: return str(int(v))
    s='%.9G'%v
    if 'E' in s:
        m,e=s.split('E'); 
        if '.' in m: m=m.rstrip('0').rstrip('.')
        sign=e[0]; e=e[1:].lstrip('0') or '0'
        return f"{m}E{sign}{int(e):02d}"
    if '.' in s: s=s.rstrip('0').rstrip('.')
    return s

class Ref:
    def __init__(s,it,key,idx=None): s.it,s.key,s.idx=it,key,idx
    def get(s): return s.it.getvar(s.key,s.idx)
    def set(s,v): s.it.setvar(s.key,s.idx,v)

class Interp:
    def __init__(self):
        self.lines={}; self.order=[]; self.vars={}; self.arrays={}; self.fns={}
        self.mem=bytearray(65536); self.stack=[]; self.fors=[]
        self.li=0; self.p=0; self.toks=[]; self.stmt_start=(0,0)
        self.onerr=None; self.running=False; self.data_ptr=None
        self.amp={}; self.calls={}; self.pokes={}; self.peeks={}; self.hooks={}
        self.out=lambda ch:None; self.trace=False; self.pending_run=None
        self.rnd=random.Random(1); self.steps=0; self.last_was_colon=False; self.max_steps=None; self.ring=[]
    # ---- program ----
    def set_lines(self,lines,merge=False):
        if not merge: self.lines={}
        self.lines.update(lines); self.order=sorted(self.lines); self.data_ptr=None
    def delete_lines(self,a,b):
        for k in [k for k in self.lines if a<=k<=b]: del self.lines[k]
        self.order=sorted(self.lines)
    def find_line(self,n):
        n=int(n)
        if n in self.lines: return self.order.index(n)
        raise AppleError(90,'UNDEF STATEMENT %d'%n)
    # ---- variables ----
    def clear(self): self.vars={}; self.arrays={}; self.fns={}; self.fors=[]; self.stack=[]
    def getvar(self,key,idx=None):
        if idx is None:
            v=self.vars.get(key)
            if v is None: v='' if key.endswith('$') else 0.0
            return v
        a=self.arrays.get(key)
        if a is None: a=self.dim(key,[10]*len(idx))
        return a[1][self._aidx(a[0],idx)]
    def setvar(self,key,idx,v):
        if key.endswith('$'):
            if not isinstance(v,str): raise AppleError(163,'TYPE MISMATCH')
        else:
            if isinstance(v,str): raise AppleError(163,'TYPE MISMATCH')
            if key.endswith('%'): v=float(int(math.floor(v)))
        if idx is None: self.vars[key]=v; return
        a=self.arrays.get(key)
        if a is None: a=self.dim(key,[10]*len(idx))
        a[1][self._aidx(a[0],idx)]=v
    def dim(self,key,maxes):
        if key in self.arrays: raise AppleError(120,'REDIM')
        sizes=[int(m)+1 for m in maxes]; cnt=1
        for s in sizes: cnt*=s
        init='' if key.endswith('$') else 0.0
        self.arrays[key]=(sizes,[init]*cnt); return self.arrays[key]
    def _aidx(self,sizes,idx):
        if len(idx)!=len(sizes): raise AppleError(107,'BAD SUBSCRIPT')
        k=0; mult=1
        for s,i in zip(sizes,idx):
            i=int(i)
            if i<0 or i>=s: raise AppleError(107,'BAD SUBSCRIPT')
            k+=i*mult; mult*=s
        return k
    # ---- token helpers ----
    def peek_tok(self): return self.toks[self.p] if self.p<len(self.toks) else ('E','')
    def at_end(self): t=self.peek_tok(); return t[0]=='E' or t==('O',':')
    def accept(self,t):
        if self.peek_tok()==t: self.p+=1; return True
        return False
    def expect(self,t):
        if not self.accept(t): raise AppleError(16,'SYNTAX: expected %s got %s at line %s ctx=%s'%(t,self.peek_tok(),self.cur_line(),self.toks[max(0,self.p-6):self.p+4]))
    def cur_line(self): return self.order[self.li] if self.li<len(self.order) else 0
    # ---- expressions ----
    def expr(self): return self.p_or()
    def p_or(self):
        v=self.p_and()
        while self.peek_tok()==('K','OR'):
            self.p+=1; r=self.p_and(); v=1.0 if (v!=0 or r!=0) else 0.0
        return v
    def p_and(self):
        v=self.p_not()
        while self.peek_tok()==('K','AND'):
            self.p+=1; r=self.p_not(); v=1.0 if (v!=0 and r!=0) else 0.0
        return v
    def p_not(self):
        if self.peek_tok()==('K','NOT'):
            self.p+=1; v=self.p_not(); return 1.0 if v==0 else 0.0
        return self.p_cmp()
    def p_cmp(self):
        v=self.p_add()
        while True:
            t=self.peek_tok()
            if t[0]=='K' and t[1] in ('<','>','='):
                ops=''
                while self.peek_tok()[0]=='K' and self.peek_tok()[1] in ('<','>','=') and len(ops)<2:
                    ops+=self.peek_tok()[1]; self.p+=1
                r=self.p_add()
                if isinstance(v,str)!=isinstance(r,str): raise AppleError(163,'TYPE MISMATCH')
                o=''.join(sorted(ops)) 
                if o=='=': res=v==r
                elif o=='<>': res=v!=r    # sorted('<>')=='<>'
                elif o=='<': res=v<r
                elif o=='>': res=v>r
                elif o=='<=' or o=='=<': res=v<=r
                elif o=='=>' or o=='>=': res=v>=r
                else: raise AppleError(16,'bad compare '+ops)
                v=1.0 if res else 0.0
            else: return v
    def p_add(self):
        v=self.p_mul()
        while True:
            t=self.peek_tok()
            if t==('K','+'):
                self.p+=1; r=self.p_mul()
                if isinstance(v,str):
                    if not isinstance(r,str): raise AppleError(163)
                    v=v+r
                    if len(v)>255: raise AppleError(176,'STRING TOO LONG')
                else:
                    if isinstance(r,str): raise AppleError(163)
                    v=v+r
            elif t==('K','-'):
                self.p+=1; r=self.p_mul(); v=v-r
            else: return v
    def p_mul(self):
        v=self.p_unary()
        while True:
            t=self.peek_tok()
            if t==('K','*'): self.p+=1; v=v*self.p_unary()
            elif t==('K','/'):
                self.p+=1; r=self.p_unary()
                if r==0: raise AppleError(133,'DIVISION BY ZERO')
                v=v/r
            else: return v
    def p_unary(self):
        t=self.peek_tok()
        if t==('K','-'): self.p+=1; return -self.p_pow()
        if t==('K','+'): self.p+=1; return self.p_pow()
        return self.p_pow()
    def p_pow(self):
        v=self.p_atom()
        while self.peek_tok()==('K','^'):
            self.p+=1; r=self.p_atom()
            try: v=float(v)**r
            except (ZeroDivisionError,OverflowError,ValueError): raise AppleError(69,'OVERFLOW')
            if isinstance(v,complex): raise AppleError(53)
        return v
    def parse_subs(self):
        idx=[]
        self.expect(('O','('))
        while True:
            idx.append(self.expr())
            if self.accept(('O',',')): continue
            self.expect(('O',')')); return idx
    def p_atom(self):
        t=self.peek_tok(); k,v=t
        if k=='N': self.p+=1; return v
        if k=='S': self.p+=1; return v
        if t==('O','('):
            self.p+=1; r=self.expr(); self.expect(('O',')')); return r
        if k=='I':
            self.p+=1
            if self.peek_tok()==('O','('): return self.getvar(v,self.parse_subs())
            return self.getvar(v)
        if t==('K','NOT'):
            self.p+=1; r=self.p_cmp(); return 1.0 if r==0 else 0.0
        if t==('K','-'): self.p+=1; return -self.p_atom()
        if t==('K','+'): self.p+=1; return self.p_atom()
        if k=='K': return self.p_func(v)
        raise AppleError(16,'SYNTAX atom %s line %s'%(t,self.cur_line()))
    def arg1(self):
        self.expect(('O','(')); v=self.expr(); self.expect(('O',')')); return v
    def num(self,v):
        if isinstance(v,str): raise AppleError(163,'TYPE MISMATCH')
        return v
    def p_func(self,f):
        self.p+=1
        if f=='FN':
            nm=self.peek_tok()[1]; self.p+=1; a=self.arg1()
            if nm not in self.fns: raise AppleError(224,'UNDEF FN')
            param,toks,start=self.fns[nm]
            old=self.vars.get(param); self.vars[param]=a
            sv=(self.toks,self.p); self.toks,self.p=toks,start
            try: r=self.expr()
            finally:
                self.toks,self.p=sv
                if old is None: self.vars.pop(param,None)
                else: self.vars[param]=old
            return r
        if f=='USR': a=self.arg1(); return float(self.hooks['usr'](self,a))
        if f=='FRE': self.arg1(); return 20000.0
        if f=='POS': self.arg1(); return float(self.hooks.get('pos',lambda:0)())
        if f=='PDL': a=self.arg1(); return 128.0
        if f=='SCRN(':
            self.expr(); self.expect(('O',',')); self.expr(); self.expect(('O',')')); return 0.0
        if f=='RND':
            a=self.num(self.arg1()); 
            if a<0: self.rnd.seed(a)
            return self.rnd.random()
        if f=='PEEK':
            a=int(self.num(self.arg1()))&0xFFFF; return float(self.peek(a))
        if f in ('LEFT$','RIGHT$','MID$'):
            self.expect(('O','(')); s=self.expr(); self.expect(('O',',')); n=int(self.num(self.expr())); m=None
            if f=='MID$' and self.accept(('O',',')): m=int(self.num(self.expr()))
            self.expect(('O',')'))
            if not isinstance(s,str): raise AppleError(163)
            if f=='MID$' and n<1 or n<0 or n>255: raise AppleError(53,'ILLEGAL QUANTITY')
            if f=='LEFT$': return s[:n]
            if f=='RIGHT$': return s[max(0,len(s)-n):]
            return s[n-1:] if m is None else s[n-1:n-1+m]
        a=self.arg1()
        if f=='LEN': return float(len(a))
        if f=='STR$': return fmt_num(self.num(a))
        if f=='CHR$': return chr(int(self.num(a))&0xFF)
        if f=='ASC':
            if not a: raise AppleError(53)
            return float(ord(a[0]))
        if f=='VAL':
            m=re.match(r'\s*[+-]?(\d+\.?\d*|\.\d+)(E[+-]?\d+)?',a.upper())
            return float(m.group(0)) if m else 0.0
        a=self.num(a)
        try:
            if f=='INT': return float(math.floor(a))
            if f=='ABS': return abs(a)
            if f=='SGN': return float((a>0)-(a<0))
            if f=='SQR':
                if a<0: raise AppleError(53)
                return math.sqrt(a)
            if f=='LOG':
                if a<=0: raise AppleError(53)
                return math.log(a)
            if f=='EXP': return math.exp(a)
            if f=='SIN': return math.sin(a)
            if f=='COS': return math.cos(a)
            if f=='TAN': return math.tan(a)
            if f=='ATN': return math.atan(a)
        except OverflowError: raise AppleError(69,'OVERFLOW')
        if f=='SGN': pass
        raise AppleError(16,'SYNTAX func %s'%f)
    # ---- memory ----
    def peek(self,a):
        h=self.peeks.get(a)
        if h: return h(a)
        return self.mem[a]
    def poke(self,a,v):
        v=int(v)&0xFF
        h=self.pokes.get(a)
        if h: h(a,v)
        self.mem[a]=v
    def addr(self,v):
        v=int(v)
        return v+65536 if v<0 else v
    # ---- ampersand arg parsing ----
    def parse_amp_args(self):
        """returns list of (value, ref_or_None); None value for empty slot; 'AT' separator marked by ('AT',None)"""
        out=[]
        if self.at_end(): return out
        self.accept(('O',','))
        if self.at_end(): return out
        while True:
            if self.accept(('O',',')): out.append((None,None)); 
            else:
                t=self.peek_tok()
                if t==('K','AT'): self.p+=1; out.append(('AT',None))
                elif t[0]=='E' or t==('O',':'): break
                else:
                    ref=None; save=self.p
                    if t[0]=='I':
                        self.p+=1; idx=None
                        if self.peek_tok()==('O','('): idx=self.parse_subs()
                        nt=self.peek_tok()
                        if nt in (('O',','),('O',':'),('K','AT')) or nt[0]=='E': ref=Ref(self,t[1],idx)
                        self.p=save
                    out.append((self.expr(),ref))
                    if self.peek_tok()==('K','AT'): continue
                    if not self.accept(('O',',')): break
                    # trailing comma then empty slot
                    t=self.peek_tok()
                    if t[0]=='E' or t==('O',':'): out.append((None,None)); break
                    continue
                continue
            # after an empty slot, we consumed the comma; next loop continues with next arg
        return out
    # ---- statements ----
    def skip_stmt(self):
        q=False
        while self.p<len(self.toks):
            t=self.toks[self.p]
            if t==('O',':'): return
            self.p+=1
    def goto(self,n): self.li=self.find_line(n); self.p=0; self.toks=self.lines[self.order[self.li]]; self.jumped=True
    def step(self):
        t=self.peek_tok(); k,v=t; self.stmt_start=(self.li,self.p)
        if k=='E': return
        if k=='R': self.p=len(self.toks); return
        if t==('O',':'): self.p+=1; self.last_was_colon=True; return
        self.last_was_colon=False
        if k=='I' or (k=='K' and v=='LET'):
            if k=='K': self.p+=1
            self.assign(); return
        if k!='K': raise AppleError(16,'SYNTAX stmt %s line %s'%(t,self.cur_line()))
        self.p+=1
        h=getattr(self,'s_'+{'&':'AMP','PR#':'PRN','IN#':'INN','HCOLOR=':'HCOLOR','ROT=':'ROT','SCALE=':'SCALE','COLOR=':'COLOR','HIMEM:':'HIMEM','LOMEM:':'LOMEM','SPEED=':'SPEED'}.get(v,v),None)
        if h is None: raise AppleError(16,'UNIMPL stmt %s line %s'%(v,self.cur_line()))
        h()
    def assign(self):
        t=self.peek_tok(); self.p+=1; idx=None
        if self.peek_tok()==('O','('): idx=self.parse_subs()
        self.expect(('K','=')); v=self.expr(); self.setvar(t[1],idx,v)
    def s_END(self): raise Stop()
    def s_STOP(self): raise Stop()
    def s_REM(self): pass
    def s_DATA(self): self.p+=1
    def s_NORMAL(self): self.hooks.get('normal',lambda:0)()
    def s_INVERSE(self): self.hooks.get('inverse',lambda:0)()
    def s_FLASH(self): self.hooks.get('flash',lambda:0)()
    def s_TEXT(self): self.hooks.get('text',lambda:0)()
    def s_HOME(self): self.hooks.get('home',lambda:0)()
    def s_HTAB(self): n=int(self.expr()); self.hooks.get('htab',lambda n:0)(n)
    def s_VTAB(self): n=int(self.expr()); self.hooks.get('vtab',lambda n:0)(n)
    def s_LOMEM(self): self.expr(); self.vars={}; self.arrays={}; self.fns={}      # LOMEM: also CLEARs variables
    def s_HIMEM(self): self.expr()
    def s_SPEED(self): self.expr()
    def s_TRACE(self): pass
    def s_NOTRACE(self): pass
    def s_HGR(self): self.hooks.get('hgr',lambda:0)()
    def s_HGR2(self): self.hooks.get('hgr2',lambda:0)()
    def s_PRN(self): self.expr()
    def s_INN(self): self.expr()
    def s_CLEAR(self): self.vars={}; self.arrays={}; self.fns={}
    def s_POKE(self):
        a=self.addr(self.expr()); self.expect(('O',',')); v=self.expr(); self.poke(a,v)
    def s_CALL(self):
        a=self.addr(self.expr()); h=self.calls.get(a)
        if h is None: raise AppleError(16,'UNIMPL CALL %d ($%04X) line %s'%(a,a,self.cur_line()))
        h(self)
    def s_DIM(self):
        while True:
            t=self.peek_tok(); self.p+=1; self.expect(('O','(')); m=[]
            while True:
                m.append(self.expr())
                if self.accept(('O',',')): continue
                self.expect(('O',')')); break
            self.dim(t[1],m)
            if not self.accept(('O',',')): break
    def s_DEF(self):
        self.expect(('K','FN')); nm=self.peek_tok()[1]; self.p+=1
        self.expect(('O','(')); param=self.peek_tok()[1]; self.p+=1; self.expect(('O',')')); self.expect(('K','='))
        self.fns[nm]=(param,self.toks,self.p)
        # skip the expression body: it extends to end of statement
        depth=0
        while self.p<len(self.toks):
            t=self.toks[self.p]
            if t==('O',':') and depth==0: break
            self.p+=1
    def s_GOTO(self): self.goto(self.expr_line())
    def expr_line(self):
        t=self.peek_tok()
        if t[0]=='N': self.p+=1; return t[1]
        return self.expr()
    def s_GOSUB(self):
        n=self.expr_line(); self.stack.append(('G',self.li,self.p,len(self.fors))); self.goto(n)
    def s_RETURN(self):
        while self.stack and self.stack[-1][0]!='G': self.stack.pop()
        if not self.stack: raise AppleError(22,'RETURN WITHOUT GOSUB')
        _,li,p,nf=self.stack.pop(); del self.fors[nf:]; self.li=li; self.p=p; self.toks=self.lines[self.order[li]]; self.jumped=True
    def s_POP(self):
        while self.stack and self.stack[-1][0]!='G': self.stack.pop()
        if not self.stack: raise AppleError(22)
        _,_,_,nf=self.stack.pop(); del self.fors[nf:]
    def s_IF(self):
        c=self.expr()
        if isinstance(c,str): raise AppleError(163)
        if c!=0:
            if self.accept(('K','THEN')):
                if self.peek_tok()[0]=='N': self.goto(self.expr_line())
            elif self.peek_tok()==('K','GOTO'): self.p+=1; self.goto(self.expr_line())
            else: raise AppleError(16,'IF without THEN line %s'%self.cur_line())
        else: self.p=len(self.toks)
    def s_ON(self):
        n=int(self.num(self.expr())); kind=self.peek_tok()[1]; self.p+=1
        if kind not in ('GOTO','GOSUB'): raise AppleError(16,'ON syntax')
        tgts=[]
        while True:
            tgts.append(self.expr_line())
            if not self.accept(('O',',')): break
        if n<0: raise AppleError(53)
        if 1<=n<=len(tgts):
            if kind=='GOSUB': self.stack.append(('G',self.li,self.p,len(self.fors)))
            self.goto(tgts[n-1])
        else: self.p=len(self.toks) if False else self.p
    def s_ONERR(self):
        self.expect(('K','GOTO')); self.onerr=int(self.expr_line()); self.mem[216]=0x80
    def s_RESUME(self):
        self.li,self.p=self.stmt_start_err; self.toks=self.lines[self.order[self.li]]; self.jumped=True
        self.stack=self.stack_err
    def s_FOR(self):
        t=self.peek_tok(); self.p+=1; key=t[1]; self.expect(('K','=')); start=self.num(self.expr())
        self.expect(('K','TO')); lim=self.num(self.expr()); step=1.0
        if self.accept(('K','STEP')): step=self.num(self.expr())
        self.setvar(key,None,start)
        base=self.stack[-1][3] if self.stack and self.stack[-1][0]=='G' else 0
        for i in range(base,len(self.fors)):
            if self.fors[i][0]==key: del self.fors[i:]; break
        self.fors.append((key,lim,step,self.li,self.p))
    def s_NEXT(self):
        while True:
            key=None
            if self.peek_tok()[0]=='I': key=self.peek_tok()[1]; self.p+=1
            base=self.stack[-1][3] if self.stack and self.stack[-1][0]=='G' else 0
            if len(self.fors)<=base: raise AppleError(0,'NEXT WITHOUT FOR')
            if key is None: f=self.fors[-1]
            else:
                idx=[i for i,f in enumerate(self.fors) if f[0]==key and i>=base]
                if not idx: raise AppleError(0,'NEXT WITHOUT FOR')
                del self.fors[idx[-1]+1:]; f=self.fors[idx[-1]]
            fk,lim,step,li,p=f
            v=self.getvar(fk)+step; self.setvar(fk,None,v)
            if (step>=0 and v<=lim) or (step<0 and v>=lim):
                self.li,self.p=li,p; self.toks=self.lines[self.order[li]]; self.jumped=True; return
            del self.fors[-1]
            if self.accept(('O',',')): continue
            return
    def s_READ(self):
        while True:
            t=self.peek_tok(); self.p+=1; idx=None
            if self.peek_tok()==('O','('): idx=self.parse_subs()
            val=self.next_data(t[1].endswith('$'))
            self.setvar(t[1],idx,val)
            if not self.accept(('O',',')): break
    def next_data(self,isstr):
        if self.data_ptr is None: self.data_ptr=[0,0,0,None]
        while True:
            li,ti,si,items=self.data_ptr
            if items is None:
                # find next DATA statement from (li,ti)
                found=False
                while li<len(self.order):
                    toks=self.lines[self.order[li]]
                    while ti<len(toks):
                        if toks[ti]==('K','DATA'):
                            txt=toks[ti+1][1] if ti+1<len(toks) and toks[ti+1][0]=='D' else ''
                            items=self.split_data(txt); self.data_ptr=[li,ti+2,0,items]; found=True; break
                        ti+=1
                    if found: break
                    li+=1; ti=0
                if not found: raise AppleError(42,'OUT OF DATA')
                continue
            if si<len(items):
                self.data_ptr[2]=si+1; s=items[si]
                if isstr: return s
                try: return float(s.strip()) if s.strip() else 0.0
                except ValueError: raise AppleError(163,'DATA type: %r'%s)
            self.data_ptr=[li,ti,0,None]
    def split_data(self,txt):
        items=[];cur='';q=False;quoted=False
        for ch in txt:
            if ch=='"': q=not q; quoted=True
            elif ch==',' and not q: items.append(cur if quoted else cur.strip()); cur='';quoted=False
            else: cur+=ch
        items.append(cur if quoted else cur.strip()); return items
    def s_RESTORE(self): self.data_ptr=None
    def s_GET(self):
        t=self.peek_tok(); self.p+=1; ch=self.hooks['getkey'](self)
        if t[1].endswith('$'): self.setvar(t[1],None,chr(ch&0x7f))
        else:
            try: self.setvar(t[1],None,float(chr(ch&0x7f)))
            except ValueError: raise AppleError(254,'BAD RESPONSE')
    def s_WAIT(self):
        self.expr(); self.expect(('O',',')); self.expr()
        if self.accept(('O',',')): self.expr()
    def s_PRINT(self):
        nl=True
        while not self.at_end():
            t=self.peek_tok()
            nl=True
            if t==('O',';'): self.p+=1; nl=False; continue
            if t==('O',','):
                self.p+=1; nl=False; self.hooks.get('comma',lambda:self.out(' '))(); continue
            if t==('K','TAB('):
                self.p+=1; n=int(self.expr()); self.expect(('O',')')); self.hooks.get('tab',lambda n:self.write(' '*max(0,n)))(n); nl=False; continue
            if t==('K','SPC('):
                self.p+=1; n=int(self.expr()); self.expect(('O',')')); self.write(' '*max(0,n)); nl=False; continue
            v=self.expr()
            self.write(v if isinstance(v,str) else fmt_num(v)); nl=True
        if nl: self.out('\r')
    def write(self,s):
        for ch in s: self.out(ch)
    def s_AMP(self):
        t=self.peek_tok()
        if t==('K','&'): self.p+=1; return                       # '& &' : drop the machine-code extension (no-op here)
        if t[0]!='C': raise AppleError(16,'SYNTAX & line %s tok %s'%(self.cur_line(),t))
        cmd=t[1]; self.p+=1
        args=self.parse_amp_args()
        h=self.amp.get(cmd)
        if h is None: raise AppleError(16,'UNIMPL &%s args=%r line %s'%(cmd,[a[0] for a in args],self.cur_line()))
        h(self,args)
    def amp_name_lookup(self,name):
        # tokens keep only 2 chars for identifiers; recover full name from the original line is not possible,
        # so the lexer stores truncated names. Re-lex using full names for & commands:
        return self.full_amp.get((self.cur_line(),self._amp_ord),name) if False else name
    # ---- run loop ----
    def run(self,start=None):
        self.running=True; self.jumped=False
        if start is None: self.li=0
        else: self.li=self.find_line(start)
        self.p=0; self.toks=self.lines[self.order[self.li]]
        while self.running:
            try:
                while self.running:
                    if self.p>=len(self.toks):
                        self.li+=1
                        if self.li>=len(self.order): self.running=False; break
                        self.toks=self.lines[self.order[self.li]]; self.p=0
                        if self.pending_run: 
                            pr=self.pending_run; self.pending_run=None; pr()
                        continue
                    self.jumped=False
                    self.steps+=1
                    if self.max_steps and self.steps>self.max_steps: raise Stop()
                    if self.steps%1==0: self.ring.append(self.cur_line()); self.ring=self.ring[-40:]
                    self.step()
                    if self.pending_run:
                        pr=self.pending_run; self.pending_run=None; pr(); continue
                    if not self.jumped:
                        t=self.peek_tok()
                        if t==('O',':'): self.p+=1
                        else: pass
            except Stop: self.running=False
            except AppleError as e:
                if self.onerr is None or self.mem[216]==0:
                    self.running=False; self.error=e; raise
                ln=self.cur_line(); self.mem[222]=e.code&0xFF; self.mem[218]=ln&0xFF; self.mem[219]=ln>>8
                self.stmt_start_err=self.stmt_start; self.stack_err=list(self.stack)
                self.err_detail=str(e); self.errlog=getattr(self,'errlog',[]); self.errlog.append((e.code,ln,str(e))); self.errring=getattr(self,'errring',[]); self.errring.append((list(self.ring[-30:]),list(self.fors)))
                self.goto(self.onerr)
