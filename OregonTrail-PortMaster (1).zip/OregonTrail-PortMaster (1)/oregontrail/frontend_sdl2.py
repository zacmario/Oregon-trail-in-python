"""SDL2 backend (PySDL2) for PortMaster handhelds. UNTESTED on real hardware: written without PySDL2 available in the authoring sandbox."""
import ctypes, os
import sdl2
W,H=320,240
class SDLAudio:
    def __init__(self):
        spec=sdl2.SDL_AudioSpec(22050,sdl2.AUDIO_S16LSB,1,1024); got=sdl2.SDL_AudioSpec(0,0,0,0)
        self.dev=sdl2.SDL_OpenAudioDevice(None,0,spec,ctypes.byref(got),0)
        if self.dev==0: raise RuntimeError('audio: '+sdl2.SDL_GetError().decode())
        sdl2.SDL_PauseAudioDevice(self.dev,0)
    def play(self,pcm,sustain):
        if sustain: sdl2.SDL_ClearQueuedAudio(self.dev)
        sdl2.SDL_QueueAudio(self.dev,pcm,len(pcm))
    def busy(self): return sdl2.SDL_GetQueuedAudioSize(self.dev)>0
    def stop(self): sdl2.SDL_ClearQueuedAudio(self.dev)
KEYS={sdl2.SDLK_UP:'UP',sdl2.SDLK_DOWN:'DOWN',sdl2.SDLK_LEFT:'LEFT',sdl2.SDLK_RIGHT:'RIGHT'}
KEYBTN={sdl2.SDLK_ESCAPE:'SELECT',sdl2.SDLK_F1:'START'}
KEYNAME={sdl2.SDLK_RETURN:'RETURN',sdl2.SDLK_KP_ENTER:'RETURN',sdl2.SDLK_BACKSPACE:'BACKSPACE',sdl2.SDLK_SPACE:'SPACE',sdl2.SDLK_TAB:'TAB'}
CBTN={sdl2.SDL_CONTROLLER_BUTTON_A:'A',sdl2.SDL_CONTROLLER_BUTTON_B:'B',sdl2.SDL_CONTROLLER_BUTTON_X:'X',sdl2.SDL_CONTROLLER_BUTTON_Y:'Y',
      sdl2.SDL_CONTROLLER_BUTTON_START:'START',sdl2.SDL_CONTROLLER_BUTTON_BACK:'SELECT',sdl2.SDL_CONTROLLER_BUTTON_DPAD_UP:'UP',
      sdl2.SDL_CONTROLLER_BUTTON_DPAD_DOWN:'DOWN',sdl2.SDL_CONTROLLER_BUTTON_DPAD_LEFT:'LEFT',sdl2.SDL_CONTROLLER_BUTTON_DPAD_RIGHT:'RIGHT'}
JBTN={0:'A',1:'B',2:'X',3:'Y',6:'SELECT',7:'START'}            # fallback for joysticks without an SDL controller mapping
class SDL2Backend:
    name='sdl2'
    def __init__(self,fullscreen=True,log=print):
        self.log=log; self.stick={}; self.pads={}
        if sdl2.SDL_Init(sdl2.SDL_INIT_VIDEO|sdl2.SDL_INIT_JOYSTICK|sdl2.SDL_INIT_GAMECONTROLLER)!=0: raise RuntimeError('SDL init: '+sdl2.SDL_GetError().decode())
        sdl2.SDL_SetHint(sdl2.SDL_HINT_RENDER_SCALE_QUALITY,b'0')
        err=lambda: sdl2.SDL_GetError().decode(errors='ignore')
        self.win=None
        for fs in ([True,False] if fullscreen else [False]):                 # fullscreen-desktop first, then a plain window
            flags=sdl2.SDL_WINDOW_SHOWN|(sdl2.SDL_WINDOW_FULLSCREEN_DESKTOP if fs else 0)
            self.win=sdl2.SDL_CreateWindow(b'The Oregon Trail',sdl2.SDL_WINDOWPOS_CENTERED,sdl2.SDL_WINDOWPOS_CENTERED,640,480,flags)
            if self.win: break
            self.log('window creation failed (fullscreen=%s): %s'%(fs,err()))
        if not self.win: raise RuntimeError('SDL_CreateWindow failed: '+err())
        self.ren=None
        for rflags,label in ((sdl2.SDL_RENDERER_ACCELERATED|sdl2.SDL_RENDERER_PRESENTVSYNC,'accelerated+vsync'),(sdl2.SDL_RENDERER_ACCELERATED,'accelerated'),(sdl2.SDL_RENDERER_SOFTWARE,'software')):
            self.ren=sdl2.SDL_CreateRenderer(self.win,-1,rflags)
            if self.ren: self.log('renderer:',label); break
            self.log('renderer %s failed: %s'%(label,err()))
        if not self.ren: raise RuntimeError('SDL_CreateRenderer failed: '+err())
        sdl2.SDL_RenderSetLogicalSize(self.ren,W,H)
        self.tex=sdl2.SDL_CreateTexture(self.ren,sdl2.SDL_PIXELFORMAT_RGB24,sdl2.SDL_TEXTUREACCESS_STREAMING,W,H)
        if not self.tex: raise RuntimeError('SDL_CreateTexture failed: '+err())
        self._warned=False
        sdl2.SDL_ShowCursor(0); sdl2.SDL_StartTextInput()
        for i in range(sdl2.SDL_NumJoysticks()): self._open(i)
        try: self.audio_backend=SDLAudio(); sdl2.SDL_InitSubSystem(sdl2.SDL_INIT_AUDIO) if False else None
        except Exception as e: self.log('audio disabled:',e); self.audio_backend=None
    def _open(self,i):
        try:
            if sdl2.SDL_IsGameController(i): self.pads[i]=sdl2.SDL_GameControllerOpen(i)
            else: self.pads[i]=sdl2.SDL_JoystickOpen(i)
        except Exception as e: self.log('pad open failed',i,e)
    def poll(self):
        out=[]; ev=sdl2.SDL_Event()
        while sdl2.SDL_PollEvent(ctypes.byref(ev)):
            t=ev.type
            if t==sdl2.SDL_QUIT: out.append(('quit',))
            elif t in (sdl2.SDL_KEYDOWN,sdl2.SDL_KEYUP):
                sym=ev.key.keysym.sym; down=(t==sdl2.SDL_KEYDOWN)
                if ev.key.repeat: continue
                if sym in KEYS: out.append(('down' if down else 'up',KEYS[sym]))
                elif sym in KEYBTN: out.append(('down' if down else 'up',KEYBTN[sym]))
                elif down and sym in KEYNAME: out.append(('key',KEYNAME[sym]))
            elif t==sdl2.SDL_TEXTINPUT: out.append(('text',ev.text.text.decode('utf8','ignore')))
            elif t in (sdl2.SDL_CONTROLLERBUTTONDOWN,sdl2.SDL_CONTROLLERBUTTONUP):
                b=CBTN.get(ev.cbutton.button)
                if b: out.append(('down' if t==sdl2.SDL_CONTROLLERBUTTONDOWN else 'up',b))
            elif t==sdl2.SDL_CONTROLLERAXISMOTION:
                ax,val=ev.caxis.axis,ev.caxis.value
                names={sdl2.SDL_CONTROLLER_AXIS_LEFTX:('LEFT','RIGHT'),sdl2.SDL_CONTROLLER_AXIS_LEFTY:('UP','DOWN')}.get(ax)
                if names:
                    for nm,on in ((names[0],val<-16000),(names[1],val>16000)):
                        if on and not self.stick.get(nm): self.stick[nm]=True; out.append(('down',nm))
                        elif not on and self.stick.get(nm): self.stick[nm]=False; out.append(('up',nm))
            elif t in (sdl2.SDL_JOYBUTTONDOWN,sdl2.SDL_JOYBUTTONUP) and not sdl2.SDL_IsGameController(ev.jbutton.which):
                b=JBTN.get(ev.jbutton.button)
                if b: out.append(('down' if t==sdl2.SDL_JOYBUTTONDOWN else 'up',b))
            elif t==sdl2.SDL_JOYHATMOTION and not sdl2.SDL_IsGameController(ev.jhat.which):
                v=ev.jhat.value
                for nm,mask in (('UP',sdl2.SDL_HAT_UP),('DOWN',sdl2.SDL_HAT_DOWN),('LEFT',sdl2.SDL_HAT_LEFT),('RIGHT',sdl2.SDL_HAT_RIGHT)):
                    on=bool(v&mask)
                    if on and not self.stick.get(nm): self.stick[nm]=True; out.append(('down',nm))
                    elif not on and self.stick.get(nm): self.stick[nm]=False; out.append(('up',nm))
            elif t==sdl2.SDL_CONTROLLERDEVICEADDED: self._open(ev.cdevice.which)
        return out
    def present(self,fb):
        if sdl2.SDL_UpdateTexture(self.tex,None,fb,W*3)!=0 and not self._warned:
            self._warned=True; self.log('SDL_UpdateTexture failed:',sdl2.SDL_GetError().decode(errors='ignore'))
        sdl2.SDL_RenderClear(self.ren)
        sdl2.SDL_RenderCopy(self.ren,self.tex,None,None); sdl2.SDL_RenderPresent(self.ren)
    def close(self):
        try:
            sdl2.SDL_DestroyTexture(self.tex); sdl2.SDL_DestroyRenderer(self.ren); sdl2.SDL_DestroyWindow(self.win); sdl2.SDL_Quit()
        except Exception: pass
