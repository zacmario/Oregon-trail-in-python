Put your two Oregon Trail (Apple II) disk images here, as .dsk files (140 KB, DOS 3.3 order). Names do not matter:
the game recognises disk 1 and disk 2 by their contents. No game data is shipped with this port.
