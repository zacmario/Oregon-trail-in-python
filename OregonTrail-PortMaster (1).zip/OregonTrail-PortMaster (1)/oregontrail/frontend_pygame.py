"""pygame backend (desktop testing / fallback). Same events as the SDL2 backend. UNTESTED: pygame was not available in the authoring sandbox."""
import pygame
W,H=320,240
class PygameBackend:
    name='pygame'
    def __init__(self,fullscreen=False,log=print):
        pygame.init(); pygame.joystick.init(); self.log=log; self.stick={}
        self.screen=pygame.display.set_mode((640,480),pygame.FULLSCREEN if fullscreen else 0); pygame.display.set_caption('The Oregon Trail'); pygame.mouse.set_visible(False)
        self.pads=[pygame.joystick.Joystick(i) for i in range(pygame.joystick.get_count())]
        for p in self.pads: p.init()
        try:
            import audio; self.audio_backend=audio.PygameBackend()
        except Exception as e: log('audio disabled:',e); self.audio_backend=None
        self.surf=None
    def poll(self):
        out=[]
        K=pygame
        keys={K.K_UP:'UP',K.K_DOWN:'DOWN',K.K_LEFT:'LEFT',K.K_RIGHT:'RIGHT',K.K_ESCAPE:'SELECT',K.K_F1:'START'}
        names={K.K_RETURN:'RETURN',K.K_KP_ENTER:'RETURN',K.K_BACKSPACE:'BACKSPACE',K.K_SPACE:'SPACE',K.K_TAB:'TAB'}
        jb={0:'A',1:'B',2:'X',3:'Y',6:'SELECT',7:'START'}
        for ev in pygame.event.get():
            if ev.type==pygame.QUIT: out.append(('quit',))
            elif ev.type in (pygame.KEYDOWN,pygame.KEYUP):
                down=ev.type==pygame.KEYDOWN
                if ev.key in keys: out.append(('down' if down else 'up',keys[ev.key]))
                elif down and ev.key in names: out.append(('key',names[ev.key]))
                if down and ev.unicode and ev.unicode.isprintable() and ev.key not in names: out.append(('text',ev.unicode))
            elif ev.type in (pygame.JOYBUTTONDOWN,pygame.JOYBUTTONUP) and ev.button in jb:
                out.append(('down' if ev.type==pygame.JOYBUTTONDOWN else 'up',jb[ev.button]))
            elif ev.type==pygame.JOYHATMOTION:
                x,y=ev.value
                for nm,on in (('LEFT',x<0),('RIGHT',x>0),('UP',y>0),('DOWN',y<0)):
                    if on and not self.stick.get(nm): self.stick[nm]=True; out.append(('down',nm))
                    elif not on and self.stick.get(nm): self.stick[nm]=False; out.append(('up',nm))
        return out
    def present(self,fb):
        surf=pygame.image.frombuffer(fb,(W,H),'RGB'); self.screen.blit(pygame.transform.scale(surf,self.screen.get_size()),(0,0)); pygame.display.flip()
    def close(self): pygame.quit()
