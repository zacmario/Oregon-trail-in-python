# The Oregon Trail (Apple II) - PortMaster build

A native Python runtime for the 1985 MECC Apple II game. It runs the **original game programs from your own disk images**; no game data
is included. The game's `&` machine-code extensions, text engine, graphics, music and hunting are reimplemented in Python.

## Install
1. Copy this folder (`Oregon Trail.sh` + `oregontrail/`) to your device's `ports` folder.
2. Copy your **two** Apple II disk images (`.dsk`, 140 KB) into `ports/oregontrail/disks/` (file names don't matter).
3. Launch "Oregon Trail" from the Ports menu. Logs go to `ports/oregontrail/log.txt`; Top Ten / tombstone data is kept in `saves/`.

Requirements: Python 3.7+ and PySDL2 (PortMaster's own `pylibs` provide it on most setups; pygame is used as a fallback).
**This build has not been tested on real handheld hardware** (it was developed on a PC without SDL); please report problems with `log.txt`.

## Controls (no keyboard needed)
| Situation | Buttons |
|---|---|
| Any text/number prompt (names, quantities) | **Up/Down** cycle through the allowed letters/numbers, **A** add the shown character, **B** delete, **Start** finish. **Left/Right** skip 5, **X** jump to next group (A-Z, a-z, 0-9, punctuation) |
| Menu choices (1-4, ...) | **Up/Down** pick, **A** select |
| Yes / No questions | **Up/Down** switch, **A** select |
| Store item choice | **Up/Down** pick 1-5 or "leave", **A** select, **Start** confirm, **B** undo |
| "Press SPACE BAR" / any key prompts | any button |
| Rafting | D-pad steers |
| Hunting | D-pad aim (diagonals by pressing two directions), **A** fire, **B** start/stop walking, **X/Y** turn rifle, **Start** end hunt |
| Quit | hold **Select + Start** for a moment |
A USB keyboard also works (type normally; Return finishes a line).

## Notes
- Hunting uses the original Apple II sprites with timing and hitboxes taken from the DOS release's code; it is a re-creation, not the original code.
- Music is synthesized from the game's own note data. Sound plays only when the game's sound option is on (main menu option 4).
- Disk images are identified by their contents, not their names. Both disks are needed (the game asks for side 2 near the end).

## Troubleshooting
- **"Need TWO Oregon Trail Apple II disk images"**: the launcher counts files of exactly 143,360 bytes (140 KB) in `ports/oregontrail/disks`
  (any name or extension). Check `log.txt`, which lists the folder. The images must be the DOS 3.3-order Apple II disks (side 1 and side 2).
- **"compositor does not implement the XDG toplevel icon protocol"** (Wayland.c): a harmless SDL warning about the window icon; ignore it.
- **Black screen / no window**: send `log.txt`. Try `--windowed` or `--backend pygame` when running by hand (`python3 oregon.py --windowed`).
