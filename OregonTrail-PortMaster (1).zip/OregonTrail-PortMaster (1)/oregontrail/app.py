"""Platform-independent application loop: runs the game in a thread, turns backend input events into game input, draws frames.
A backend (frontend_sdl2.py / frontend_pygame.py / a fake one in tests) provides:
   poll() -> list of events: ('down',BUTTON) ('up',BUTTON) ('key',NAME) ('text',str) ('quit',)
   present(rgb_bytes_320x240)   audio_backend (or None)   close()
Buttons: UP DOWN LEFT RIGHT A B X Y START SELECT.  Keys (keyboard): RETURN BACKSPACE SPACE TAB ESCAPE F1."""
import threading, time, traceback, sys
import controls
from hgr_rgb import Canvas
DIRS=('UP','DOWN','LEFT','RIGHT')
class App:
    def __init__(self,game,backend,fps=30,log=None):
        self.game=game; self.b=backend; self.fps=fps; self.canvas=Canvas(game.font); self.held={}; self.pad_mode=True
        self.done=False; self.error=None; self.log=log or (lambda *a:None); self.frames=0
        game.headless=False; game.quit=False
        if getattr(backend,'audio_backend',None): game.audio.set_backend(backend.audio_backend)
    # ---- input ----
    def press(self,btn):
        g=self.game
        if g.mode in ('raft','hunt') and len(g.keys)>3: return        # don't let held-direction repeats pile up
        controls.route(g,btn)
    def handle(self,ev):
        k=ev[0]; now=time.time()
        if k=='quit': self.done=True
        elif k=='down':
            if ev[1] not in self.held: self.held[ev[1]]=[now,now]; self.press(ev[1])
        elif k=='up': self.held.pop(ev[1],None)
        elif k=='key':
            name=ev[1]
            if name=='ESCAPE': self.held['SELECT']=self.held.get('SELECT',[now,now])
            m={'RETURN':'A' if self.pad_mode else 'START','BACKSPACE':'B','SPACE':'X','TAB':'Y','F1':'START'}.get(name)
            if m: self.press(m)
        elif k=='text' and self.game.mode in ('text','choice'):
            self.pad_mode=False
            for ch in ev[1]:
                if 32<=ord(ch)<127: self.game.keys.append(ord(ch))
    def repeat(self):
        now=time.time()
        for b,(t0,tl) in list(self.held.items()):
            if b in DIRS and now-t0>0.40 and now-tl>0.09: self.held[b][1]=now; self.press(b)
        if 'SELECT' in self.held and 'START' in self.held and now-max(self.held['SELECT'][0],self.held['START'][0])>0.6: self.done=True
    # ---- game thread ----
    def run_game(self,program='MENU'):
        try: self.game.run_program(program)
        except Exception: self.error=traceback.format_exc(); self.log(self.error)
        self.done=True
    def run(self,program='MENU'):
        th=threading.Thread(target=self.run_game,args=(program,),daemon=True); th.start(); dt=1.0/self.fps
        try:
            while not self.done:
                t0=time.time()
                for ev in self.b.poll(): self.handle(ev)
                self.repeat()
                self.b.present(self.canvas.frame(bytes(self.game.scr.scr),controls.hint(self.game))); self.frames+=1
                rest=dt-(time.time()-t0)
                if rest>0: time.sleep(rest)
        finally:
            self.game.quit=True; time.sleep(0.05); self.b.close()
        return self.error
