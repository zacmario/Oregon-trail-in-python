"""Pure-Python hi-res -> RGB conversion and 320x240 canvas composition (game at 280x192 plus a help bar). No numpy/PIL needed."""
COL={'blk':(0,0,0),'wht':(255,255,255),'vio':(255,68,253),'grn':(20,245,60),'blu':(20,207,253),'org':(255,106,60)}
W,H=320,240; GX,GY=20,6                                     # game area offset inside the canvas
_cache={}
def _chunk(a,b):
    """Two adjacent hi-res bytes (14 pixels, starting on an even x) -> 42 RGB bytes."""
    bits=[(a>>k)&1 for k in range(7)]+[(b>>k)&1 for k in range(7)]; pal=[a>>7]*7+[b>>7]*7; out=bytearray()
    for i in range(0,14,2):
        e,o,p=bits[i],bits[i+1],pal[i]
        if not (e or o): c=COL['blk']
        elif e and o: c=COL['wht']
        elif o: c=COL['org'] if p else COL['grn']
        else: c=COL['blu'] if p else COL['vio']
        out+=bytes(c)*2
    return bytes(out)
def game_rows(scr):
    """scr: column-major bytes (40 columns x 192 rows). Returns a list of 192 RGB rows (840 bytes each)."""
    cols=[scr[c*192:(c+1)*192] for c in range(40)]; rows=[]; cache=_cache
    for r in zip(*cols):
        parts=[]
        for m in range(20):
            k=(r[2*m],r[2*m+1]); v=cache.get(k)
            if v is None: v=cache[k]=_chunk(*k)
            parts.append(v)
        rows.append(b''.join(parts))
    return rows
class Canvas:
    def __init__(self,font):
        self.font=font; self.bar=None; self.bar_key=None
        self.pad_l=bytes(GX*3); self.pad_r=bytes((W-GX-280)*3); self.blank=bytes(W*3)
    def text_bar(self,lines,color=(190,190,190),height=H-(GY+192)):
        """Render help lines into RGB rows using the game's own proportional font."""
        rows=[bytearray(W*3) for _ in range(height)]
        for li,line in enumerate(lines):
            x=6; y=3+li*10
            for ch in line:
                adv,sh,data=self.font.glyph.get(ord(ch)&0x7f,(6,0,b''))
                for r,b in enumerate(data):
                    for k in range(8):
                        if (b>>k)&1:
                            px=x+k; py=y+sh+r
                            if 0<=px<W and 0<=py<height: rows[py][px*3:px*3+3]=bytes(color)
                x+=adv+1
        return [bytes(r) for r in rows]
    def frame(self,scr,hint_lines):
        key=tuple(hint_lines)
        if key!=self.bar_key: self.bar=self.text_bar(hint_lines); self.bar_key=key
        out=[self.blank]*GY
        for r in game_rows(scr): out.append(self.pad_l+r+self.pad_r)
        out+=self.bar
        return b''.join(out)                              # W*H*3 bytes, RGB
