"""Music for the MECC runtime (pure Python, no numpy). Tune files (MS*.BIN / TS.BIN): byte0 = tune count, then 16-bit offsets
(tune n at word n); each tune is (pitch,duration) byte pairs ending at a byte >= $80. The original tone generator ($7F2B) toggles the
speaker with period (w0+w1)*24 cycles from a pitch table, for duration*256*24 cycles. Pitch table recovered from the runtime image."""
import wave
from array import array
CYC=24.0; CLOCK=1_023_000.0; RATE=22050

def pitch_table(img,base=0x3400,addr=0x7FC8,n=64):
    return [(img[addr-base+2*i],img[addr-base+2*i+1]) for i in range(n)]
def tune_pointer(data,n):
    if not data or n<=0 or n>data[0]: return None
    return data[2*n]|data[2*n+1]<<8
def parse_tune(data,n,table):
    p=tune_pointer(data,n)
    if p is None: return []
    notes=[]
    while p+1<len(data) and data[p]<0x80:
        pitch,dur=data[p],data[p+1]; p+=2
        w0,w1=table[pitch] if pitch<len(table) else (0,0)
        f=CLOCK/(CYC*(w0+w1)) if (w0+w1) else 0.0          # 0 => rest
        notes.append((f,dur*256*CYC/CLOCK))
    return notes
_patterns={}
def _pattern(f,rate,amp):
    key=(round(f,2),rate,amp)
    p=_patterns.get(key)
    if p is None:
        period=rate/f; best=1
        for m in range(1,24):                              # choose M cycles so M*period is almost an integer (accurate pitch)
            if abs(m*period-round(m*period))<0.05: best=m; break
        total=max(2,int(round(best*period)))
        p=array('h',[amp if ((i*best/total)%1.0)<0.5 else -amp for i in range(total)]); _patterns[key]=p
    return p
def synth(notes,rate=RATE,volume=0.25):
    """notes -> signed 16-bit little-endian mono PCM bytes"""
    amp=int(volume*32767); out=array('h')
    for f,d in notes:
        n=int(rate*d)
        if f<=0: out.extend(array('h',bytes(2*n))); continue
        p=_pattern(f,rate,amp); seg=(p*(n//len(p)+1))[:n]
        fade=min(n//2,int(rate*0.004))
        for i in range(fade): v=i/fade; seg[i]=int(seg[i]*v); seg[n-1-i]=int(seg[n-1-i]*v)
        out.extend(seg)
    if out and array('h',[1]).itemsize==2:
        import sys
        if sys.byteorder=='big': out.byteswap()
    return out.tobytes()
def write_wav(path,pcm,rate=RATE):
    with wave.open(path,'wb') as w: w.setnchannels(1); w.setsampwidth(2); w.setframerate(rate); w.writeframes(pcm)

class PygameBackend:
    def __init__(self):
        import pygame; pygame.mixer.init(RATE,-16,1); self.m=pygame.mixer
    def play(self,pcm,sustain):
        snd=self.m.Sound(buffer=pcm); ch=self.m.find_channel() or self.m.Channel(0)
        if sustain: ch.stop(); ch.play(snd)
        elif ch.get_busy(): ch.queue(snd)
        else: ch.play(snd)
    def busy(self): return bool(self.m.get_busy())
    def stop(self): self.m.stop()
class Audio:
    """Plays through a backend (SDL2 frontend / pygame); with no backend it only records requests (headless/tests)."""
    def __init__(self,backend=None):
        self.log=[]; self.backend=backend; self.current=None
    def set_backend(self,b): self.backend=b
    def play(self,pcm,key=None,sustain=False):
        self.log.append(key)
        if self.backend is None or not pcm: self.current=key; return
        if sustain and self.current==key and self.playing(): return
        self.backend.play(pcm,sustain); self.current=key
    def playing(self): return bool(self.backend and self.backend.busy())
    def stop(self):
        if self.backend: self.backend.stop()
        self.current=None
