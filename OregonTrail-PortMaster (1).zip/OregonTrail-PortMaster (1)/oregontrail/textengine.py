"""Text engine matching MECC's hi-res runtime: window-relative cursor, buffered word-wrapped lines,
control chars (FF clear screen, CR, CE clear-to-eol, CF clear-to-eow, CC center line), HSP/VSP spacing."""
def install(G):
    def te_init(self):
        self.win={0:(0,0,279,191)}; self.curwin=0; self.rx=0; self.ry=0
        self.hsp=1; self.vsp=1; self.tsp=0; self.buf=[]    # buf: list of (char, inverse)
    G.te_init=te_init
    def winrect(self): return self.win.get(self.curwin,self.win[0])
    G.winrect=winrect
    def advance(self,ch): 
        adv,sh,data=self.font.glyph.get(ord(ch)&0x7f,(6,0,b'')); return adv+self.hsp
    G.advance=advance
    def bufwidth(self,items): return sum(self.advance(c) for c,_ in items)
    G.bufwidth=bufwidth
    def draw_char(self,x,y,ch,inv):
        adv,sh,data=self.font.glyph.get(ord(ch)&0x7f,(6,0,b''))
        s=self.scr
        if inv:
            s.fill(x,y,x+adv+self.hsp-1,y+7,3)
        for r,b in enumerate(data):
            for k in range(8):
                if (b>>k)&1: s.setpix(x+k,y+sh+r,not inv)
    G.draw_char=draw_char
    def lineh(self): return 8+self.vsp+self.tsp
    G.lineh=lineh
    def flush(self,center=False):
        if not self.buf: return
        x1,y1,x2,y2=self.winrect()
        w=self.bufwidth(self.buf)
        if center: self.rx=max(0,((x2-x1+1)-w)//2)
        x=x1+self.rx
        for c,inv in self.buf: self.draw_char(x,y1+self.ry,c,inv); x+=self.advance(c)
        self.rx+=w; self.buf=[]
    G.flush=flush
    def newline(self):
        x1,y1,x2,y2=self.winrect(); self.rx=0; self.ry+=self.lineh()
        if y1+self.ry+8>y2: self.ry=0
    G.newline=newline
    def cout(self,ch):
        o=ord(ch)&0x7f; x1,y1,x2,y2=self.winrect()
        if o>=32:
            inv=self.inverse; w=self.advance(ch)
            if x1+self.rx+self.bufwidth(self.buf)+w>x2+1:
                # word wrap: break at last space in buffer
                sp=max([i for i,(c,_) in enumerate(self.buf) if c==' '],default=-1)
                if sp>=0:
                    rest=self.buf[sp+1:]; self.buf=self.buf[:sp]; self.flush(); self.newline(); self.buf=rest
                else: self.flush(); self.newline()
                if ch==' ' and not self.buf: return
            self.buf.append((ch,inv)); return
        if o==3: self.flush(center=True); return
        self.flush()
        if o==13: self.newline()
        elif o==10: self.rx=self.rx; self.ry+=self.lineh(); 
        elif o==12: self.scr.clear(); self.rx=self.ry=0
        elif o==2: self.rx=self.ry=0; self.scr.fill(x1,y1,x2,y2,0)
        elif o==5: self.scr.fill(x1+self.rx,y1+self.ry,x2,y1+self.ry+self.lineh()-1,0)
        elif o==6: self.scr.fill(x1+self.rx,y1+self.ry,x2,y1+self.ry+self.lineh()-1,0); self.scr.fill(x1,y1+self.ry+self.lineh(),x2,y2,0)
        elif o==8: self.rx=max(0,self.rx-6)
        elif o==9: self.rx+=6
    G.cout=cout
    def a_WIND(self,it,a):
        self.flush(); v=self.A(a); n=int(v[0]) if v and v[0] is not None else 0
        self.curwin=n if n in self.win else 0; self.rx=self.ry=0
    G.a_WIND=a_WIND
    def a_DFW(self,it,a):
        self.flush(); v=self.A(a); n=int(v[0]); nums=[int(x) for x in v[2:] if x not in (None,'AT')]
        x,y,w,h=nums[:4]; self.win[n]=(x,y,min(279,x+w),min(191,y+h))
    G.a_DFW=a_DFW
    def a_CO(self,it,a):
        self.flush(); v=self.A(a)
        if not v: self.rx=self.ry=0; return
        if v[0] is not None: self.rx=int(v[0])
        if len(v)>1 and v[1] is not None: self.ry=int(v[1])
    G.a_CO=a_CO
    def a_GCP(self,it,a):
        self.flush()
        if len(a)>0 and a[0][1] is not None: a[0][1].set(float(self.rx))
        if len(a)>1 and a[1][1] is not None: a[1][1].set(float(self.ry))
    G.a_GCP=a_GCP
    def a_HSP(self,it,a): self.flush(); v=self.A(a); self.hsp=int(v[0]) if v and v[0] is not None else 1
    def a_VSP(self,it,a): self.flush(); v=self.A(a); self.vsp=int(v[0]) if v and v[0] is not None else 1
    def a_TSP(self,it,a): self.flush(); v=self.A(a); self.tsp=int(v[0]) if v and v[0] is not None else 0
    G.a_HSP=a_HSP; G.a_VSP=a_VSP; G.a_TSP=a_TSP
    def a_CEL(self,it,a): self.cout('\x05')
    def a_CEW(self,it,a): self.cout('\x06')
    G.a_CEL=a_CEL; G.a_CEW=a_CEW
    old_getkey=G.getkey
    def getkey(self,it): self.flush(); return old_getkey(self,it)
    G.getkey=getkey
    old_usr=G.usr
    def usr(self,it,a): self.flush(); return old_usr(self,it,a)
    G.usr=usr
