"""Oregon Trail (Apple II) native runtime: original BASIC runs on applesoft.py; MECC & commands implemented here."""
import sys, os
sys.path.insert(0,os.path.dirname(__file__))
from applesoft import Interp, parse_program, AppleError, Stop, fmt_num
from disk import Disk
from font import Font
import varimg
from cpu6502 import CPU, Halt
import audio as _audio
import ime as _ime

COL={'blk':(0,0,0),'wht':(255,255,255),'vio':(255,68,253),'grn':(20,245,60),'blu':(20,207,253),'org':(255,106,60)}
def unrle(data,p=0):
    out=bytearray()
    while p<len(data):
        op=data[p]
        if op==0xC0: break
        n=(op&0x3F)+1
        if op<0x40: out+=data[p+1:p+1+n]; p+=1+n
        elif op<0x80: out+=bytes([data[p+1]])*n; p+=2
        else: out+=bytes([data[p+1],data[p+2]])*n; p+=3
    return bytes(out)
def parse_imageset(data):
    ents=[]; first=None; i=0
    while i+1<len(data):
        w=data[i]|data[i+1]<<8; off=w&0x3FFF
        if first is None: first=off if off>=2 else None
        elif off and off<first: first=off
        if first is not None and i>=first: break
        ents.append((off,w>>14)); i+=2
    return ents

class Screen:
    W,H=280,192
    def __init__(self): self.scr=bytearray(40*192); self.log=[]
    def clear(self,v=0): self.scr=bytearray([v])*(40*192)
    def setpix(self,x,y,on=True,pal=None):
        if not(0<=x<280 and 0<=y<192): return
        c=x//7; i=c*192+y; b=x%7
        if on: self.scr[i]|=1<<b
        else: self.scr[i]&=~(1<<b)&0xFF
        if pal is not None: self.scr[i]=(self.scr[i]&0x7F)|(pal<<7)
    def fill(self,x1,y1,x2,y2,color):
        x1=max(0,x1); y1=max(0,y1); x2=min(279,x2); y2=min(191,y2)
        if x1>x2 or y1>y2: return
        ev=color in (2,3,6,7); od=color in (1,3,5,7); pal=1 if color>=4 else 0
        for c in range(x1//7,x2//7+1):
            M=0; P=0
            for k in range(7):
                x=c*7+k
                if x1<=x<=x2:
                    M|=1<<k
                    if (od if x&1 else ev): P|=1<<k
            base=c*192; seg=self.scr[base+y1:base+y2+1]
            keep=(~M)&0x7F
            self.scr[base+y1:base+y2+1]=bytes(((v&keep)|P)&0x7F|(pal<<7) for v in seg)
    def blit(self,x,y,w,h,cols,mode='copy'):
        c0=x//7
        for c in range(w):
            cc=c0+c
            if not 0<=cc<40: continue
            for r in range(h):
                yy=y+r
                if 0<=yy<192:
                    v=cols[c*h+r] if c*h+r<len(cols) else 0
                    self.scr[cc*192+yy]=v
    def image(self,pal=True):
        from PIL import Image
        im=Image.new('RGB',(280,192)); px=im.load()
        for y in range(192):
            bits=[];pl=[]
            for c in range(40):
                b=self.scr[c*192+y]
                for k in range(7): bits.append((b>>k)&1); pl.append(b>>7)
            for x in range(0,280,2):
                e,o=bits[x],bits[x+1]
                if not(e or o): continue
                p=pl[x]
                col=COL['wht'] if (e and o) else (COL['org'] if p else COL['grn']) if o else (COL['blu'] if p else COL['vio'])
                px[x,y]=col; px[x+1,y]=col
        return im

class Game:
    def __init__(self,d1,d2=None,keys=None,strict=False):
        self.disks=[Disk(d1)]+([Disk(d2)] if d2 else []); self.side=0
        self.it=Interp(); self.scr=Screen(); self.font=Font(self.disks[0].image_dos())
        self.keys=list(keys or []); self.strict=strict; self.unimpl={}; self.trace_amp=[]
        self.inverse=False; self.te_init()
        self.quit=False; self.mode='space'; self.pending=None; self.feeder=None; self.ime_cands=[]; self.ime_idx=0
        self.sets={}; self.curset=None; self.fontset={}
        self.hcolor=3; self.screen_dumps=[]; self.fileptr=None; self.seq=None
        it=self.it; it.out=self.cout
        it.hooks.update(usr=self.usr,getkey=self.getkey,home=self.home,inverse=lambda:setattr(self,'inverse',True),
                        normal=lambda:setattr(self,'inverse',False),htab=lambda n:None,vtab=lambda n:None,tab=lambda n:self.it.write(' '*max(0,n)),
                        comma=lambda:self.cout(' '))
        it.peeks[0xC000]=lambda a: (self.keys[0]|0x80) if self.keys else 0
        it.pokes[0xC010]=lambda a,v: self.keys.pop(0) if self.keys else None
        it.calls.update({0xFC58:lambda it:self.home(),-936+65536:lambda it:self.home()})
        for ad in (54915,2208): it.calls[ad]=lambda it_:None
        for name in dir(self):
            if name.startswith('a_'): it.amp[name[2:]]=getattr(self,name)
        self.audio=_audio.Audio(); self.ptable=_audio.pitch_table(self.disks[0].image_dos())
        self.cpu=CPU(it.mem); img=self.disks[0].d
        it.mem[0x3400:0x3400+0x6000]=img[:0x6000]                       # runtime image (tracks 0-5)
        lc=img[6*4096:9*4096]                                              # language card image (tracks 6-8) loads at $D100
        self.cpu.bank[2][0x100:0x1000]=lc[:0xF00]; it.mem[0xE000:0x10000]=lc[0xF00:0xF00+0x2000]
        it.mem[0xE6]=0x20                                                 # hi-res page byte (HGR page 1)
        self.cpu.keys=self.keys; self.polls=0; self.cpu.on_poll=self.cpu_poll
        it.s_HCOLOR=lambda: setattr(self,'hcolor',int(it.expr()))
        it.s_HPLOT=self.s_hplot
    # ----- disk side helpers -----
    @property
    def disk(self): return self.disks[min(self.side,len(self.disks)-1)]
    def findfile(self,name):
        for d in [self.disk]+self.disks:
            if d.has(name): return d
        raise AppleError(6,'FILE NOT FOUND '+name)
    def getfile(self,name): return self.findfile(name).read(name)
    # ----- io -----
    def usr(self,it,a):
        n=int(a)
        if n==1: return 0                                    # clear keyboard strobe / start-of-wait (non-blocking)
        self.mode={3:'raft',5:'digits'}.get(n,'space')
        if n==5: self.cycle_keys(['1','2','3','4','5',' '])
        elif self.keys and self.keys[0]>=256: self.keys.pop(0)
        if self.keys: self.idle=0; self.audio.stop(); self.pending=None; return self.keys.pop(0)|0x80
        if self.feeder and not self.keys and n!=3 and self.feeder(self): return 0
        if self.quit: raise Stop()
        self.idle=getattr(self,'idle',0)+1
        if getattr(self,'headless',True):
            if self.idle>3000: raise Stop()                  # headless: no more input queued
        else:
            import time; time.sleep(0.002)
        return 0                                             # others: timed poll / delay
    def cycle_keys(self,cands):
        """Digit/choice cycling for polled key reads (USR(5)): process cycle codes at the head of the queue."""
        if not hasattr(self,'cidx') or self.ccands!=cands: self.ccands=cands; self.cidx=0
        while self.keys and self.keys[0]>=256:
            code=self.keys.pop(0); self.cidx,act=_ime.handle(code,cands,self.cidx)
            if act=='accept': self.keys.insert(0,ord(cands[self.cidx]))
            elif act=='back': self.keys.insert(0,8)
        self.pending=cands[self.cidx]; self.ime_cands=cands; self.ime_idx=self.cidx
    def getkey(self,it):
        import time
        while not self.keys:
            if self.quit: raise Stop()
            if self.feeder and self.feeder(self): continue
            if getattr(self,'headless',True): raise Stop()   # headless: no more input
            time.sleep(0.004)
        k=self.keys.pop(0)
        while k>=256 and self.keys: k=self.keys.pop(0)
        return k if k<256 else 32
    def home(self): self.scr.clear(); self.rx=self.ry=0
    def s_hplot(self):
        it=self.it; pts=[]
        x=int(it.expr()); it.expect(('O',',')); y=int(it.expr()); pts.append((x,y))
        while it.accept(('K','TO')):
            x2=int(it.expr()); it.expect(('O',',')); y2=int(it.expr()); pts.append((x2,y2))
        if len(pts)==1: self.scr.fill(x,y,x,y,self.hcolor)
        for (a,b),(c,d) in zip(pts,pts[1:]):
            n=max(abs(c-a),abs(d-b),1)
            for i in range(n+1): self.scr.fill(a+(c-a)*i//n,b+(d-b)*i//n,a+(c-a)*i//n,b+(d-b)*i//n,self.hcolor)
    def winrect(self): return self.win.get(self.curwin,self.win[0])
    def newline(self):
        x1,y1,x2,y2=self.winrect(); self.cx=x1; self.cy+=8+self.vsp
        if self.cy+8>y2+1:
            self.cy=y1
    def cout(self,ch):
        o=ord(ch)&0x7f; x1,y1,x2,y2=self.winrect()
        if o==13: self.newline(); return
        if o==12: self.scr.fill(x1,y1,x2,y2,0); self.cx=x1; self.cy=y1; return
        if o==5:  self.scr.fill(self.cx,self.cy,x2,self.cy+7,0); return      # clear to end of line
        if o==3:  self.scr.fill(self.cx,self.cy,x2,self.cy+7,3 if self.inverse else 0); self.newline(); return
        if o==6:  self.scr.fill(x1,self.cy,x2,self.cy+7,0); self.cx=x1; return
        if o<32: return
        adv,sh,data=self.font.glyph.get(o,(6,0,b''))
        if self.cx+adv>x2+1: self.newline()
        for r,b in enumerate(data):
            for k in range(8):
                on=(b>>k)&1
                if on!=(1 if self.inverse else 0): pass
                if self.inverse: self.scr.setpix(self.cx+k,self.cy+(sh&0x1f)+r,not on) if k<adv else None
                elif on: self.scr.setpix(self.cx+k,self.cy+(sh&0x1f)+r,True)
        self.cx+=adv+self.hsp
    # ----- & commands (args: list of (value,ref)) -----
    def A(self,args): return [a[0] for a in args]
    def a_HOOK(self,it,a): pass
    def a_UNHOOK(self,it,a): pass
    def a_SET(self,it,a): v=self.A(a); self.side=int(v[0])-1 if v and v[0] is not None else 0
    def a_CDN(self,it,a):
        d=self.disk; nm=[n for n,(ft,_,_) in d.cat.items() if ft==1][0]
        a[0][1].set(nm)
    def a_RFL(self,it,a):
        v=self.A(a); name=v[0]; addr=int(v[2]) if len(v)>2 and v[2] is not None else None
        data=self.getfile(name)
        if addr is None: return
        self.cpu_load(addr,data)
        if name=='PT.BIN': return
        if name=='VAR.BIN': self.load_vars(data,addr); return
        for i,b in enumerate(data): it.mem[(addr+i)&0xFFFF]=b
        if name.endswith('.IMA') or name.endswith('.BIN'): self.sets[addr]=bytes(data)
    def load_vars(self,data,addr):
        d=self.disks[0]; pt=d.read('PT.BIN'); ptrs=[pt[i]|pt[i+1]<<8 for i in range(0,12,2)]
        V,Ar=varimg.load(data,addr,ptrs); it=self.it
        it.vars.update(V)
        for k,(dims,vals) in Ar.items(): it.arrays[k]=(list(reversed(dims)) if False else list(dims)[::-1] if False else list(dims),vals)
        # header dims are stored last-subscript-first; interpreter wants first-subscript-first
        for k,(dims,vals) in Ar.items(): it.arrays[k]=(list(reversed(dims)),vals)
    def cpu_load(self,addr,data):
        if 0xC000<=addr<0xD000: self.cpu.bank[1][addr-0xC000:addr-0xC000+len(data)]=data[:0x1000-(addr-0xC000)]   # engine maps $Cxxx -> LC bank 1
        elif addr<0xC000: self.it.mem[addr:addr+len(data)]=data
        elif addr>=0xD000: self.it.mem[addr:addr+len(data)]=data[:0x10000-addr]
    @staticmethod
    def hgr_addr(y): return 0x2000+(y&7)*0x400+((y>>3)&7)*0x80+(y>>6)*0x28
    def sync_to_cpu(self):
        m=self.it.mem; s=self.scr.scr
        for y in range(192):
            b=self.hgr_addr(y); m[b:b+40]=bytes(s[c*192+y] for c in range(40))
    def sync_from_cpu(self):
        m=self.it.mem; s=self.scr.scr
        for y in range(192):
            b=self.hgr_addr(y)
            for c in range(40): s[c*192+y]=m[b+c]
    def cpu_poll(self):
        self.polls+=1
        if self.polls%400==0:
            self.sync_from_cpu()
            if not getattr(self,'headless',True):
                import time; time.sleep(0.004)
            elif self.polls>self.max_polls: raise Halt('no more input (headless)')
    max_polls=20000
    use_cpu_hunt=False      # experimental: run the original machine-code hunting game on the 6502 core (needs more engine state)
    def a_HUNT(self,it,a):
        if self.use_cpu_hunt: return self.a_HUNT_cpu(it,a)
        import hunt
        self.flush(); v=self.A(a); z=int(v[0])
        flags=tuple(int(v[i]) if len(v)>i and v[i] is not None else 1 for i in (1,2,3))
        skill=int(v[5]) if len(v)>5 and v[5] is not None else 1
        self.cout('\x0c'); self.mode='hunt'
        try: pounds,left,kills=hunt.play(self,z,flags,skill)
        finally: self.mode='space'
        if len(a)>6 and a[6][1] is not None: a[6][1].set(float(pounds))
        if len(a)>7 and a[7][1] is not None: a[7][1].set(float(left))
    def a_HUNT_cpu(self,it,a):
        self.flush(); v=self.A(a); cpu=self.cpu; m=it.mem
        z=int(v[0]); m[0x8AE9]=z&255; m[0x8AEA]=(z>>8)&255
        for i in range(5): m[0x8AEB+i]=int(v[1+i])&255 if v[1+i] is not None else 0
        m[0x8AF0]=m[0x8AF1]=0
        self.sync_to_cpu(); cpu.cur=2; self.polls=0
        try: cpu.call(0xE003,a=0xE9,y=0x8A,maxi=60_000_000)
        except Halt as e: self.hunt_note=str(e)
        self.sync_from_cpu()
        L=m[0x8AF0]|m[0x8AF1]<<8; Z=m[0x8AE9]|m[0x8AEA]<<8
        if len(a)>6 and a[6][1] is not None: a[6][1].set(float(L))
        if len(a)>7 and a[7][1] is not None: a[7][1].set(float(Z))
    def a_APP(self,it,a):
        it.set_lines(parse_program(self.getfile(self.A(a)[0])),merge=True)
    def a_DBL(self,it,a): v=self.A(a); it.delete_lines(int(v[0]),int(v[1]))
    def a_RNH(self,it,a):
        name=self.A(a)[0].strip(); d=self.findfile(name)
        if d.cat[name][0]==4:                                   # machine-code add-on (DALLESUTIL.OBJ adds &PUTP/&DPB): natively provided
            return
        lines=parse_program(self.getfile(name))
        def go(): it.set_lines(lines); it.stack=[]; it.fors=[]; it.li=-1; it.p=10**9; it.toks=[]
        it.pending_run=go
    def a_WIND(self,it,a):
        v=self.A(a); n=int(v[0]) if v and v[0] is not None else 0
        self.curwin=n if n in self.win else 0
        x1,y1,x2,y2=self.winrect(); self.cx=x1; self.cy=y1
    def a_DFW(self,it,a):
        v=self.A(a)   # DFW, n AT x,y,w,h
        n=int(v[0]); nums=[int(x) for x in v[2:] if x not in (None,'AT')]
        x,y,w,h=nums[:4]; self.win[n]=(x,y,x+w,y+h)
    def a_CO(self,it,a):
        v=self.A(a)
        if not v: x1,y1,_,_=self.winrect(); self.cx=x1; return
        pass
        if len(v)>1 and v[1] is not None: self.cy=int(v[1])
    def a_GCP(it_,self_,a=None): pass
    def a_HSP(self,it,a): v=self.A(a); self.hsp=int(v[0]) if v and v[0] is not None else 0
    def a_VSP(self,it,a): v=self.A(a); self.vsp=int(v[0]) if v and v[0] is not None else 0
    def a_BOX(self,it,a):
        v=[int(x) for x in self.A(a)[:5] if x is not None]
        if len(v)<4: self.scr.clear(); return
        x1=(v[0]//7)*7; x2=(v[2]//7)*7+6
        self.scr.fill(x1,v[1],x2,v[3],v[4] if len(v)>4 else 0)
    def a_DUN(self,it,a):
        v=self.A(a); name=v[0]; d=unrle(self.getfile(name))
        if len(d)==7680:
            for i,b in enumerate(d): self.scr.scr[i]=b
    def a_QFH(self,it,a): self.snap('QFH')
    def a_CST(self,it,a): pass
    def a_DFT(self,it,a):
        v=self.A(a); self.fontset[int(v[0])]=int(v[1]); self.curset=self.fontset.get(7,self.curset)
    def a_UIM(self,it,a):
        v=self.A(a); n=int(v[0]); addr=int(v[1]); data=self.sets.get(self.curset)
        w=h=0; cols=b''
        if isinstance(data,(bytes,bytearray)):
            ents=parse_imageset(data)
            if 0<=n<len(ents) and ents[n][0]:
                p=ents[n][0]; w,h=data[p],data[p+1]; cols=unrle(data,p+2)
        self.sets[addr]=('IMG',w,h,cols)                      # unpacked frame buffer (overwrites whatever was at addr)
        if len(a)>2 and a[2][1] is not None: a[2][1].set(float(max(1,w*h+2)))
    def a_IMAGE(self,it,a):
        v=self.A(a); n,x,y=int(v[0]),int(v[1]),int(v[2]); data=self.sets.get(self.curset)
        if not data: return
        if isinstance(data,tuple):
            _,w,h,cols=data
            if w and h: self.scr.blit(x,y,w,h,cols)
            return
        fl=self.flagged(data,n)
        if fl:                                                    # flagged image: raw rows, pixel-accurate position
            w,h,rows=fl; self.draw_sprite(x,y,w,h,rows,'mask' if self.is_mask(w,h,rows) else 'or'); return
        ents=parse_imageset(data)
        if n>=len(ents) or ents[n][0]==0: return
        p=ents[n][0]; w,h=data[p],data[p+1]; cols=unrle(data,p+2)
        self.scr.blit(x,y,w,h,cols)
    def a_IN(self,it,a): pass
    # ---- flagged (uncompressed, row-major, pixel-shifted) sprites: ORSPRITE.IMA mask/sprite pairs ----
    def flagged(self,data,n):
        ents=parse_imageset(data)
        if n<0 or n>=len(ents) or not ents[n][0] or not (data[2*n+1]&0x80): return None
        p=ents[n][0]; w,h=data[p],data[p+1]; return w,h,data[p+2:p+2+w*h]
    @staticmethod
    def is_mask(w,h,rows):
        ones=sum(bin(b&0x7f).count('1') for b in rows); return ones>0.5*w*h*7
    def draw_sprite(self,x,y,w,h,rows,mode):
        s=self.scr
        for r in range(h):
            yy=y+r
            if not 0<=yy<192: continue
            for k in range(w*7):
                b=rows[r*w+k//7]; bit=(b>>(k%7))&1; xx=x+k
                if not 0<=xx<280: continue
                if mode=='mask':
                    if not bit: s.setpix(xx,yy,False)          # mask 0 = sprite covers: clear
                else:
                    if bit: s.setpix(xx,yy,True,b>>7)
    def a_DPB(self,it,a): v=self.A(a); self.dpb=getattr(self,'dpb',{}); self.dpb[int(v[0])]=int(v[1]); self.saved=getattr(self,'saved',{})
    def a_PUTP(self,it,a):
        # & PUTP,slot,pair AT x,y : restore slot's saved background, save new background, draw mask(pair)+sprite(pair+1)
        v=self.A(a); slot=int(v[0]); pair=int(v[1]); nums=[int(q) for q in v[2:] if q not in (None,'AT')]; x,y=nums[0],nums[1]
        self.saved=getattr(self,'saved',{}); data=self.sets.get(self.curset)
        old=self.saved.get(slot)
        if old:
            c0,y0,cols=old
            for i,col in enumerate(cols):
                if c0+i<40: self.scr.scr[(c0+i)*192+y0:(c0+i)*192+y0+len(col)]=col
        mk=self.flagged(data,pair) if isinstance(data,(bytes,bytearray)) else None
        sp=self.flagged(data,pair+1) if isinstance(data,(bytes,bytearray)) else None
        if not mk or not sp: self.saved[slot]=None; return
        w,h,mrows=mk; _,_,srows=sp
        c0=max(0,x//7); c1=min(39,(x+w*7-1)//7); y0=max(0,y); y1=min(191,y+h-1)
        if y1>=y0 and c1>=c0: self.saved[slot]=(c0,y0,[bytes(self.scr.scr[c*192+y0:c*192+y1+1]) for c in range(c0,c1+1)])
        else: self.saved[slot]=None
        self.draw_sprite(x,y,w,h,mrows,'mask'); self.draw_sprite(x,y,w,h,srows,'or')
    # ---- sequential/record text files (TOMB.SEQ, HISCORE.SEQ, OREGON1/2.SEQ) ----
    def a_OPEN(self,it,a):
        name=self.A(a)[0]; d=self.findfile(name)
        self.files=getattr(self,'files',{}); key=(self.disks.index(d),name)
        if key not in self.files:
            data=d.readraw(name); p=self.save_path(key)
            if p and os.path.exists(p):                      # saved Top Ten / tombstone data from an earlier session
                try: data=bytearray(open(p,'rb').read())
                except OSError: pass
            self.files[key]=data
        self.cur=self.files[key]; self.ptr=0; self.curkey=key; self.dirty=False
    def a_TPTR(self,it,a): self.ptr=int(self.A(a)[0])
    def a_TREED(self,it,a):
        v=self.A(a); delim=ord(v[0])&0x7f if isinstance(v[0],str) and v[0] else 13
        buf=bytearray(); p=self.ptr; data=self.cur
        while p<len(data):
            b=data[p]&0x7f
            if b==delim: p+=1; break
            if data[p]==0: break
            buf.append(b); p+=1
        self.ptr=p; s=bytes(buf).decode('latin1')
        if len(a)>1 and a[1][1] is not None: a[1][1].set(s)
        if len(a)>2 and a[2][1] is not None: a[2][1].set(float(len(s)))
    def a_TWRITE(self,it,a):
        s=self.A(a)[0]; data=self.cur
        for ch in s:
            if self.ptr<len(data): data[self.ptr]=ord(ch)|0x80 if ord(ch)!=13 else 0x8D
            self.ptr+=1; self.dirty=True
    save_dir=None            # set to a folder to persist HISCORE/TOMB writes between runs
    def save_path(self,key):
        return os.path.join(self.save_dir,'disk%d_%s.bin'%(key[0]+1,key[1].replace('/','_'))) if self.save_dir else None
    def a_CLOSE(self,it,a):
        p=self.save_path(getattr(self,'curkey',None) or (0,'')) if getattr(self,'dirty',False) else None
        if p:
            os.makedirs(self.save_dir,exist_ok=True); open(p,'wb').write(bytes(self.cur)); self.dirty=False
    def a_TAKE(self,it,a):
        self.flush(); v=[int(x) for x in self.A(a) if x is not None]; x1,y1,x2,y2,addr=v[:5]
        c1,c2=x1//7,min(39,x2//7); cols=[bytes(self.scr.scr[c*192+y1:c*192+y2+1]) for c in range(c1,c2+1)]
        self.takes=getattr(self,'takes',{}); self.takes[addr]=(c1,y1,cols)
    def a_PUT(self,it,a):
        self.flush(); v=[int(x) for x in self.A(a) if x is not None]; x,y,addr=v[:3]
        t=getattr(self,'takes',{}).get(addr)
        if not t: return
        c1,y1,cols=t; c0=x//7
        for i,col in enumerate(cols):
            cc=c0+i
            if cc<40: self.scr.scr[cc*192+y:cc*192+y+len(col)]=col
    def a_SPACE(self,it,a):
        v=self.A(a)
        if v and v[0] is not None: self.cx+=int(v[0]); return      # & SPACE,n : advance cursor n px
        self.mode='space'; self.snap('SPACE'); self.getkey(it)       # & SPACE : wait for a key
    def allowed(self,spec):
        s=set(); i=0
        while i<len(spec):
            if spec[i]=='-' and i+2<len(spec)+0 and i+2<=len(spec)-1+0 or (spec[i]=='-' and len(spec)-i>=3):
                for c in range(ord(spec[i+1]),ord(spec[i+2])+1): s.add(chr(c))
                i+=3
            else: s.add(spec[i]); i+=1
        return s
    def pending_draw(self,c):
        self.flush(); x1,y1,x2,y2=self.winrect(); px=x1+self.rx; py=y1+self.ry
        self.scr.fill(px,py,px+9,py+7,0)
        if c is not None:
            g=' ' if c==' ' else ('#' if c=='\x01' else c)
            adv=self.advance(g if g!=' ' else 'M'); self.scr.fill(px,py,px+adv,py+7,3)
            if g!=' ': self.draw_char(px,py,g,True)
    def a_INP(self,it,a):
        # & INP,maxlen,"allowed",flag,var : line input. Keyboard typing works; on handhelds UP/DOWN cycle through the allowed characters.
        v=self.A(a); maxlen=int(v[0]); ok=self.allowed(v[1] or ''); flag=int(v[2]) if len(v)>2 and v[2] is not None else 0
        cands=_ime.candidates(ok); idx=0; buf=''; yn_done=False; self.mode='choice' if maxlen==1 else 'text'
        self.ime_cands=cands; self.ime_idx=idx
        self.snap('INP'); self.flush(); self.pending=cands[idx]; self.pending_draw(self.pending)
        while True:
            k=self.getkey_raw(it)
            if k>=256:
                idx,act=_ime.handle(k,cands,idx)
                if act=='accept': k=ord(cands[idx]); yn_done=(cands==['Y','N'])
                elif act=='back': k=8
                else: self.ime_idx=idx; self.pending=cands[idx]; self.pending_draw(self.pending); continue
            k&=0x7f
            if k==13:
                if buf or not flag: self.pending_draw(None); self.cout('\r'); break
                continue
            if k in (8,127):
                if buf:
                    ch=buf[-1]; buf=buf[:-1]; w=self.advance(ch); self.pending_draw(None); self.flush()
                    self.rx=max(0,self.rx-w); x1,y1,x2,y2=self.winrect(); self.scr.fill(x1+self.rx,y1+self.ry,x1+self.rx+w,y1+self.ry+7,0)
                    self.pending_draw(self.pending)
                continue
            c=chr(k)
            if c in ok and len(buf)<maxlen:
                self.pending_draw(None); buf+=c
                if k>=32: self.cout(c); self.flush()
                if len(buf)==maxlen: break
                if yn_done: self.cout('\r'); break                # D-pad Yes/No: finish immediately
                self.pending_draw(self.pending)
        self.pending=None; self.mode='space'
        a[-1][1].set(buf)
    def getkey_raw(self,it):
        import time
        while not self.keys:
            if self.quit: raise Stop()
            if self.feeder and self.feeder(self): continue
            if getattr(self,'headless',True): raise Stop()
            time.sleep(0.004)
        return self.keys.pop(0)
    def a_CEL(self,it,a): pass
    def a_CEW(self,it,a): pass
    def a_PT(self,it,a):
        # & PT,tune[,flag]: play a tune from the music table (DFT,15 pointer). flag<>0: music while waiting for a key.
        v=self.A(a); n=int(v[0]) if v and v[0] is not None else 1; flag=int(v[1]) if len(v)>1 and v[1] is not None else 0
        data=self.sets.get(self.fontset.get(15))
        if not isinstance(data,(bytes,bytearray)): return
        key=(self.fontset.get(15),n)
        if self.audio.backend is None: self.audio.log.append(key); return
        if flag and self.audio.current==key and self.audio.playing(): return
        self.pcm_cache=getattr(self,'pcm_cache',{}); ck=(key,hash(bytes(data[:64])))
        if ck not in self.pcm_cache: self.pcm_cache[ck]=_audio.synth(_audio.parse_tune(data,n,self.ptable))
        self.audio.play(self.pcm_cache[ck],key=key,sustain=bool(flag))
    def a_PN(self,it,a): pass
    def a_DPC(self,it,a):
        if a and a[-1][1] is not None: a[-1][1].set(0.0)
    record_snaps=False                 # tests set this True; the runtime must not build images (needs Pillow, leaks memory)
    def snap(self,tag):
        if self.record_snaps: self.screen_dumps.append((tag,self.scr.image()))
    def unknown(self,it,a): pass
    def run_program(self,name,start=None,maxsteps=None):
        it=self.it; it.set_lines(parse_program(self.getfile(name)))
        # fallback for missing & handlers: log + noop
        for cmd in ['AFT','PARSE','NOPARSE','HT','VT','CHIGH','SHIGH','GTP']:
            if cmd not in it.amp: it.amp[cmd]=(lambda c: (lambda it_,a: self.unimpl.__setitem__(c,self.unimpl.get(c,0)+1)))(cmd)
        it.run(start)

from textengine import install
install(Game)
